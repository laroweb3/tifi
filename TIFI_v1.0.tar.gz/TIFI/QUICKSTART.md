# TIFI - Guía de Inicio Rápido

Esta guía te ayudará a tener tu nodo TIFI funcionando en menos de 5 minutos.

## 📥 Paso 1: Instalación

### Linux

```bash
# Descargar TIFI
git clone https://github.com/tifi/tifi.git
cd tifi

# Instalar (requiere sudo)
sudo python3 install.py
```

### Windows

```batch
# Descargar TIFI
# Descomprimir el archivo
cd TIFI

# Ejecutar instalador (como Administrador)
python install.py
```

## 🚀 Paso 2: Iniciar el Nodo

### Linux

```bash
# Opción 1: Como servicio (recomendado)
sudo systemctl start tifi
sudo systemctl status tifi

# Opción 2: Manual
tifi-node
```

### Windows

```batch
# Opción 1: Doble clic en el acceso directo del escritorio
# "TIFI Node"

# Opción 2: Desde línea de comandos
python "C:\Program Files\TIFI\tifi_node.py"
```

## 💼 Paso 3: Configurar Wallet

### Primera Vez

Al iniciar por primera vez, se creará automáticamente un wallet nuevo.

**⚠️ IMPORTANTE**: Se mostrará un **seed phrase de 24 palabras**:

```
1. palabra1    2. palabra2    3. palabra3    4. palabra4
5. palabra5    6. palabra6    7. palabra7    8. palabra8
...
```

**¡GUARDA ESTAS PALABRAS EN UN LUGAR SEGURO!**

Son necesarias para recuperar tu wallet si pierdes acceso.

### Obtener tu Primera Dirección

```bash
tifi-cli getnewaddress --label "Principal"
```

Resultado:
```
Nueva dirección: T1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9
Etiqueta: Principal
```

## 💰 Paso 4: Empezar a Minar

La minería se inicia automáticamente cuando ejecutas el nodo.

### Ver Estado de Minería

```bash
tifi-cli getinfo
```

Verás algo como:
```
=== Información del Nodo TIFI ===
Altura de blockchain: 150
Dificultad: 20
...
Minería:
  Estado: ACTIVO ✓
  Hashrate: 1234.56 H/s
  Bloques encontrados: 3
```

### Detener/Iniciar Minería Manualmente

```python
# Desde Python
from tifi_node import TIFINode

node = TIFINode()
node.stop_mining()   # Detener
node.start_mining()  # Iniciar
```

## 🏦 Paso 5: Hacer Staking (Opcional)

Una vez que tengas al menos 100 CRED, puedes hacer staking.

### Añadir Stake

```python
# Desde Python
node.staking_manager.add_stake(
    address="T1tu_direccion...",
    amount=100.0
)

# Iniciar staking
node.staking_manager.start_staking()
```

### Auto-Stake

```python
# Hacer stake de todos los fondos (dejando 10 CRED de reserva)
node.staking_manager.auto_stake_all(reserve=10.0)
```

## 📊 Paso 6: Verificar Balance

```bash
# Ver balance total
tifi-cli getbalance

# Ver balance por dirección
tifi-cli listaddresses
```

## 💸 Paso 7: Enviar CRED

```bash
tifi-cli send <dirección_destino> <cantidad>
```

Ejemplo:
```bash
tifi-cli send T1abc123... 50.5
```

## 📜 Paso 8: Ver Transacciones

```bash
tifi-cli listtransactions
```

## 🔧 Comandos Útiles

### Información General

```bash
tifi-cli getinfo          # Info completa del nodo
tifi-cli getbalance       # Balance del wallet
tifi-cli getblockcount    # Altura de blockchain
```

### Wallet

```bash
tifi-cli getnewaddress              # Nueva dirección
tifi-cli listaddresses              # Listar direcciones
tifi-cli listtransactions           # Historial
tifi-cli backupwallet <ruta>        # Backup
```

### Blockchain

```bash
tifi-cli getblock <altura>          # Info de bloque
```

### Claves

```bash
tifi-cli exportprivkey <dirección>  # Exportar clave
tifi-cli importprivkey <clave>      # Importar clave
```

## 🔄 Sincronización

El nodo se sincroniza automáticamente con la red al iniciar.

Verás mensajes como:
```
Sincronizando blockchain...
Sincronización: 150/500 bloques
✓ Blockchain sincronizada
```

## 🌐 Verificar Conectividad

```bash
tifi-cli getinfo
```

Busca la sección "Red P2P":
```
Red P2P:
  Peers: 8 conectados
  Mensajes: 1234 recibidos
```

Si ves 0 peers:
1. Verifica tu firewall (puerto 8333)
2. Espera unos minutos para descubrimiento automático
3. Verifica tu conexión a internet

## 🛑 Detener el Nodo

### Linux (servicio)

```bash
sudo systemctl stop tifi
```

### Manual

Presiona `Ctrl+C` en la terminal donde está corriendo.

## 🔐 Seguridad

### Backup del Wallet

```bash
# Crear backup
tifi-cli backupwallet ~/tifi_backup_$(date +%Y%m%d).json

# Verificar backup
ls -lh ~/tifi_backup_*.json
```

### Restaurar Wallet

```bash
# Detener nodo
sudo systemctl stop tifi

# Restaurar backup
cp ~/tifi_backup_20231210.json ~/.tifi/wallet.json

# Reiniciar nodo
sudo systemctl start tifi
```

## ❓ Problemas Comunes

### "Fondos insuficientes"

- Espera a minar algunos bloques
- Verifica tu balance: `tifi-cli getbalance`

### "No hay peers conectados"

- Verifica firewall (puerto 8333)
- Espera 2-3 minutos para descubrimiento
- Verifica conexión a internet

### "Error de permisos"

Linux:
```bash
sudo chown -R $USER:$USER ~/.tifi
```

Windows:
- Ejecuta como Administrador

### "Python no encontrado"

- Instala Python 3.8+ desde python.org
- Verifica: `python3 --version`

## 📚 Más Información

- **README completo**: Ver `README.md`
- **Arquitectura**: Ver `TIFI_ARCHITECTURE.md`
- **Documentación técnica**: Ver carpeta `docs/`

## 🎉 ¡Listo!

Tu nodo TIFI está funcionando. Ahora:

1. ✅ Estás minando bloques
2. ✅ Participando en la red P2P
3. ✅ Ganando recompensas en CRED

**"Como una flor, donde el software es ejecutado, así crece la red"** 🌸

---

¿Necesitas ayuda? Abre un issue en GitHub o únete a nuestra comunidad.
