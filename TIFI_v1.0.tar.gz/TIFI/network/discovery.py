"""
TIFI Blockchain - Peer Discovery
Descubrimiento automático de peers en la red
"""

import asyncio
import socket
import json
import time
from typing import List, Tuple, Optional


class PeerDiscovery:
    """Descubrimiento de peers"""
    
    DISCOVERY_PORT = 8334
    BROADCAST_INTERVAL = 30  # segundos
    DISCOVERY_MESSAGE = b'TIFI_DISCOVERY'
    
    def __init__(self, node_port: int, peer_manager):
        self.node_port = node_port
        self.peer_manager = peer_manager
        self.running = False
        self.socket: Optional[socket.socket] = None
    
    async def start(self):
        """Inicia el descubrimiento de peers"""
        self.running = True
        
        # Iniciar broadcast UDP
        asyncio.create_task(self._broadcast_presence())
        
        # Iniciar listener UDP
        asyncio.create_task(self._listen_for_peers())
        
        # Conectar a bootstrap nodes
        asyncio.create_task(self._connect_to_bootstrap())
        
        print(f"✓ Descubrimiento de peers iniciado en puerto {self.DISCOVERY_PORT}")
    
    async def stop(self):
        """Detiene el descubrimiento"""
        self.running = False
        if self.socket:
            self.socket.close()
    
    async def _broadcast_presence(self):
        """Broadcast de presencia en la red local"""
        # Crear socket UDP para broadcast
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        message = json.dumps({
            "type": "discovery",
            "port": self.node_port,
            "timestamp": time.time()
        }).encode()
        
        while self.running:
            try:
                # Broadcast en red local
                sock.sendto(message, ('<broadcast>', self.DISCOVERY_PORT))
                
                # También enviar a multicast
                sock.sendto(message, ('224.0.0.1', self.DISCOVERY_PORT))
                
            except Exception as e:
                print(f"Error en broadcast: {e}")
            
            await asyncio.sleep(self.BROADCAST_INTERVAL)
        
        sock.close()
    
    async def _listen_for_peers(self):
        """Escucha broadcasts de otros peers"""
        # Crear socket UDP
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', self.DISCOVERY_PORT))
        sock.setblocking(False)
        
        self.socket = sock
        
        while self.running:
            try:
                # Recibir mensaje
                data, addr = await asyncio.get_event_loop().sock_recvfrom(sock, 1024)
                
                # Parsear mensaje
                try:
                    message = json.loads(data.decode())
                    
                    if message.get("type") == "discovery":
                        peer_port = message.get("port")
                        peer_address = addr[0]
                        
                        # No añadir a nosotros mismos
                        if peer_address != "127.0.0.1" and peer_address != self._get_local_ip():
                            # Añadir peer
                            self.peer_manager.add_peer(peer_address, peer_port)
                            print(f"✓ Peer descubierto: {peer_address}:{peer_port}")
                
                except json.JSONDecodeError:
                    pass
            
            except BlockingIOError:
                await asyncio.sleep(0.1)
            except Exception as e:
                print(f"Error escuchando peers: {e}")
                await asyncio.sleep(1)
        
        sock.close()
    
    async def _connect_to_bootstrap(self):
        """Conecta a nodos bootstrap"""
        bootstrap_nodes = self.peer_manager.get_bootstrap_nodes()
        
        for address, port in bootstrap_nodes:
            try:
                # Resolver DNS
                resolved_address = await self._resolve_dns(address)
                
                if resolved_address:
                    # Añadir a peer manager
                    self.peer_manager.add_peer(resolved_address, port)
                    print(f"✓ Bootstrap node añadido: {address} ({resolved_address}:{port})")
            
            except Exception as e:
                # Silenciar errores de DNS para bootstrap nodes que no existen
                if "11001" not in str(e) and "getaddrinfo" not in str(e):
                    print(f"✗ Error conectando a bootstrap {address}: {e}")
    
    async def _resolve_dns(self, hostname: str) -> Optional[str]:
        """Resuelve un hostname a IP"""
        try:
            loop = asyncio.get_event_loop()
            result = await loop.getaddrinfo(hostname, None, family=socket.AF_INET)
            
            if result:
                return result[0][4][0]
        except Exception as e:
            # Silenciar errores de DNS para dominios que no existen
            pass
        
        return None
    
    def _get_local_ip(self) -> str:
        """Obtiene la IP local"""
        try:
            # Crear socket temporal para obtener IP local
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            return local_ip
        except:
            return "127.0.0.1"
    
    async def request_peers_from_network(self):
        """Solicita lista de peers a peers conocidos"""
        from protocol import MessageFactory
        
        # Solicitar peers a todos los peers conectados
        getpeers_msg = MessageFactory.create_getpeers()
        await self.peer_manager.broadcast_message(getpeers_msg)
    
    async def discover_peers_dht(self):
        """Descubre peers usando DHT (simplificado)"""
        # En una implementación completa, esto usaría Kademlia DHT
        # Por ahora, solo solicitamos peers a peers conocidos
        await self.request_peers_from_network()


class DNSSeeder:
    """DNS Seeder para obtener nodos iniciales"""
    
    DNS_SEEDS = [
        "seed1.tifi.network",
        "seed2.tifi.network",
        "seed3.tifi.network"
    ]
    
    @staticmethod
    async def get_seed_nodes() -> List[Tuple[str, int]]:
        """Obtiene nodos desde DNS seeds"""
        nodes = []
        
        for seed in DNSSeeder.DNS_SEEDS:
            try:
                # Resolver DNS
                loop = asyncio.get_event_loop()
                result = await loop.getaddrinfo(seed, 8333, family=socket.AF_INET)
                
                for addr_info in result:
                    ip = addr_info[4][0]
                    port = addr_info[4][1]
                    nodes.append((ip, port))
                
                print(f"✓ DNS seed {seed}: {len(result)} nodos")
            
            except Exception as e:
                # Silenciar errores de DNS para seeds que no existen
                if "11001" not in str(e) and "getaddrinfo" not in str(e):
                    print(f"✗ Error con DNS seed {seed}: {e}")
        
        return nodes


class NetworkCrawler:
    """Crawler para explorar la red"""
    
    def __init__(self, peer_manager):
        self.peer_manager = peer_manager
        self.visited_peers = set()
    
    async def crawl_network(self, max_depth: int = 3):
        """Explora la red recursivamente"""
        print(f"Iniciando crawl de red (profundidad máxima: {max_depth})")
        
        # Obtener peers iniciales
        initial_peers = self.peer_manager.get_all_peers()
        
        for peer in initial_peers:
            await self._crawl_peer(peer.address, peer.port, 0, max_depth)
    
    async def _crawl_peer(self, address: str, port: int, depth: int, max_depth: int):
        """Explora un peer y sus conexiones"""
        if depth >= max_depth:
            return
        
        peer_addr = f"{address}:{port}"
        
        if peer_addr in self.visited_peers:
            return
        
        self.visited_peers.add(peer_addr)
        
        # Conectar al peer
        connection = await self.peer_manager.connect_to_peer(address, port)
        
        if not connection:
            return
        
        # Solicitar sus peers
        from protocol import MessageFactory
        getpeers_msg = MessageFactory.create_getpeers()
        await connection.send_message(getpeers_msg)
        
        # Esperar respuesta (simplificado)
        await asyncio.sleep(2)
        
        # Explorar peers descubiertos
        new_peers = self.peer_manager.get_all_peers()
        
        for peer in new_peers:
            new_addr = f"{peer.address}:{peer.port}"
            if new_addr not in self.visited_peers:
                await self._crawl_peer(peer.address, peer.port, depth + 1, max_depth)
