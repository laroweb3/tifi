"""
TIFI Blockchain - Peer Management
Gestión de conexiones con peers
"""

import asyncio
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from protocol import Message, MessageFactory


@dataclass
class PeerInfo:
    """Información de un peer"""
    address: str
    port: int
    last_seen: float
    version: int = 0
    user_agent: str = ""
    height: int = 0
    latency: float = 0.0
    connected: bool = False
    
    def get_address_string(self) -> str:
        return f"{self.address}:{self.port}"
    
    def is_alive(self, timeout: int = 300) -> bool:
        """Verifica si el peer está vivo (visto en los últimos N segundos)"""
        return time.time() - self.last_seen < timeout
    
    def to_dict(self) -> Dict:
        return {
            "address": self.address,
            "port": self.port,
            "last_seen": self.last_seen,
            "version": self.version,
            "user_agent": self.user_agent,
            "height": self.height,
            "latency": self.latency,
            "connected": self.connected
        }


class PeerConnection:
    """Conexión con un peer"""
    
    def __init__(self, peer_info: PeerInfo, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.peer_info = peer_info
        self.reader = reader
        self.writer = writer
        self.connected = True
        self.last_ping = 0.0
        self.pending_pings: Dict[int, float] = {}
    
    async def send_message(self, message: Message):
        """Envía un mensaje al peer"""
        try:
            data = message.serialize()
            self.writer.write(data)
            await self.writer.drain()
        except Exception as e:
            print(f"Error enviando mensaje a {self.peer_info.get_address_string()}: {e}")
            self.connected = False
    
    async def receive_message(self) -> Optional[Message]:
        """Recibe un mensaje del peer"""
        try:
            # Leer header (14 bytes)
            header = await self.reader.readexactly(14)
            
            # Parsear longitud del payload
            import struct
            payload_len = struct.unpack('!I', header[6:10])[0]
            
            # Leer payload
            payload = await self.reader.readexactly(payload_len)
            
            # Deserializar mensaje completo
            full_data = header + payload
            message = Message.deserialize(full_data)
            
            return message
        except asyncio.IncompleteReadError:
            self.connected = False
            return None
        except Exception as e:
            print(f"Error recibiendo mensaje de {self.peer_info.get_address_string()}: {e}")
            self.connected = False
            return None
    
    async def ping(self) -> Optional[float]:
        """Envía un ping y espera pong"""
        import random
        nonce = random.randint(0, 2**32 - 1)
        
        ping_msg = MessageFactory.create_ping(nonce)
        start_time = time.time()
        
        self.pending_pings[nonce] = start_time
        await self.send_message(ping_msg)
        
        # Esperar pong (con timeout)
        try:
            await asyncio.wait_for(self._wait_for_pong(nonce), timeout=5.0)
            latency = time.time() - start_time
            self.peer_info.latency = latency
            return latency
        except asyncio.TimeoutError:
            return None
    
    async def _wait_for_pong(self, nonce: int):
        """Espera un pong específico"""
        while nonce in self.pending_pings:
            await asyncio.sleep(0.1)
    
    def handle_pong(self, nonce: int):
        """Maneja un pong recibido"""
        if nonce in self.pending_pings:
            del self.pending_pings[nonce]
    
    async def close(self):
        """Cierra la conexión"""
        self.connected = False
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except:
            pass


class PeerManager:
    """Gestor de peers"""
    
    MAX_PEERS = 125
    MAX_OUTBOUND = 8
    MAX_INBOUND = 117
    PEER_TIMEOUT = 300  # 5 minutos
    PING_INTERVAL = 60  # 1 minuto
    
    def __init__(self):
        self.peers: Dict[str, PeerInfo] = {}
        self.connections: Dict[str, PeerConnection] = {}
        self.bootstrap_nodes = [
            ("seed1.tifi.network", 8333),
            ("seed2.tifi.network", 8333),
            ("seed3.tifi.network", 8333)
        ]
    
    def add_peer(self, address: str, port: int) -> bool:
        """Añade un peer a la lista"""
        peer_addr = f"{address}:{port}"
        
        if peer_addr in self.peers:
            # Actualizar last_seen
            self.peers[peer_addr].last_seen = time.time()
            return False
        
        if len(self.peers) >= self.MAX_PEERS:
            # Remover peers inactivos
            self._cleanup_inactive_peers()
            
            if len(self.peers) >= self.MAX_PEERS:
                return False
        
        peer_info = PeerInfo(
            address=address,
            port=port,
            last_seen=time.time()
        )
        
        self.peers[peer_addr] = peer_info
        return True
    
    def remove_peer(self, peer_addr: str):
        """Remueve un peer"""
        if peer_addr in self.peers:
            del self.peers[peer_addr]
        
        if peer_addr in self.connections:
            del self.connections[peer_addr]
    
    def get_peer(self, peer_addr: str) -> Optional[PeerInfo]:
        """Obtiene información de un peer"""
        return self.peers.get(peer_addr)
    
    def get_all_peers(self) -> List[PeerInfo]:
        """Obtiene todos los peers"""
        return list(self.peers.values())
    
    def get_connected_peers(self) -> List[PeerInfo]:
        """Obtiene peers conectados"""
        return [p for p in self.peers.values() if p.connected]
    
    def get_peer_count(self) -> Tuple[int, int]:
        """Retorna (total_peers, connected_peers)"""
        total = len(self.peers)
        connected = len([p for p in self.peers.values() if p.connected])
        return total, connected
    
    def _cleanup_inactive_peers(self):
        """Limpia peers inactivos"""
        inactive = []
        
        for peer_addr, peer_info in self.peers.items():
            if not peer_info.is_alive(self.PEER_TIMEOUT):
                inactive.append(peer_addr)
        
        for peer_addr in inactive:
            self.remove_peer(peer_addr)
    
    async def connect_to_peer(self, address: str, port: int) -> Optional[PeerConnection]:
        """Conecta a un peer"""
        peer_addr = f"{address}:{port}"
        
        # Verificar si ya está conectado
        if peer_addr in self.connections:
            return self.connections[peer_addr]
        
        try:
            # Establecer conexión TCP
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(address, port),
                timeout=10.0
            )
            
            # Crear peer info si no existe
            if peer_addr not in self.peers:
                self.add_peer(address, port)
            
            peer_info = self.peers[peer_addr]
            peer_info.connected = True
            
            # Crear conexión
            connection = PeerConnection(peer_info, reader, writer)
            self.connections[peer_addr] = connection
            
            print(f"✓ Conectado a {peer_addr}")
            
            return connection
        
        except asyncio.TimeoutError:
            print(f"✗ Timeout conectando a {peer_addr}")
            return None
        except Exception as e:
            print(f"✗ Error conectando a {peer_addr}: {e}")
            return None
    
    async def disconnect_from_peer(self, peer_addr: str):
        """Desconecta de un peer"""
        if peer_addr in self.connections:
            connection = self.connections[peer_addr]
            await connection.close()
            del self.connections[peer_addr]
        
        if peer_addr in self.peers:
            self.peers[peer_addr].connected = False
    
    async def broadcast_message(self, message: Message, exclude: Optional[List[str]] = None):
        """Envía un mensaje a todos los peers conectados"""
        exclude = exclude or []
        
        for peer_addr, connection in self.connections.items():
            if peer_addr not in exclude and connection.connected:
                await connection.send_message(message)
    
    async def ping_all_peers(self):
        """Envía ping a todos los peers conectados"""
        for peer_addr, connection in list(self.connections.items()):
            if connection.connected:
                latency = await connection.ping()
                if latency is None:
                    # Peer no responde, desconectar
                    await self.disconnect_from_peer(peer_addr)
    
    def get_bootstrap_nodes(self) -> List[Tuple[str, int]]:
        """Obtiene los nodos bootstrap"""
        return self.bootstrap_nodes
    
    def get_stats(self) -> Dict:
        """Obtiene estadísticas de peers"""
        total, connected = self.get_peer_count()
        
        avg_latency = 0.0
        if connected > 0:
            latencies = [p.latency for p in self.peers.values() if p.connected and p.latency > 0]
            if latencies:
                avg_latency = sum(latencies) / len(latencies)
        
        return {
            "total_peers": total,
            "connected_peers": connected,
            "max_peers": self.MAX_PEERS,
            "avg_latency": avg_latency,
            "bootstrap_nodes": len(self.bootstrap_nodes)
        }
