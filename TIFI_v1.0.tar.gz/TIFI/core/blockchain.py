"""
TIFI Blockchain - Blockchain Module
Maneja la cadena de bloques, UTXO set y validación
"""

import json
import os
from typing import List, Dict, Optional, Tuple
from block import Block, BlockHeader
from transaction import Transaction, TransactionPool


class Blockchain:
    """Cadena de bloques TIFI"""
    
    # Parámetros de la blockchain
    INITIAL_REWARD = 50.0
    HALVING_INTERVAL = 210_000
    MAX_SUPPLY = 21_000_000
    BLOCK_TIME_TARGET = 60  # segundos
    DIFFICULTY_ADJUSTMENT_INTERVAL = 20  # bloques
    INITIAL_DIFFICULTY = 20
    
    # Parámetros de consenso híbrido
    POW_CYCLE_LENGTH = 7  # 7 bloques PoW
    POS_CYCLE_LENGTH = 3  # 3 bloques PoS
    CYCLE_LENGTH = POW_CYCLE_LENGTH + POS_CYCLE_LENGTH  # 10 bloques total
    
    def __init__(self, data_dir: str = "~/.tifi"):
        self.data_dir = os.path.expanduser(data_dir)
        os.makedirs(self.data_dir, exist_ok=True)
        
        self.chain: List[Block] = []
        self.utxo_set: Dict[str, Dict] = {}  # {tx_id:output_index -> {amount, address}}
        self.transaction_pool = TransactionPool()
        
        # Índices para búsqueda rápida
        self.block_index: Dict[str, Block] = {}  # hash -> block
        self.height_index: Dict[int, Block] = {}  # height -> block
        
        # Cargar o crear blockchain
        self._load_or_create()
    
    def _load_or_create(self):
        """Carga la blockchain desde disco o crea una nueva"""
        chain_file = os.path.join(self.data_dir, "chain.json")
        
        if os.path.exists(chain_file):
            self._load_from_disk()
        else:
            self._create_genesis()
    
    def _create_genesis(self):
        """Crea el bloque génesis"""
        genesis = Block.create_genesis_block()
        self.chain.append(genesis)
        self._update_indices(genesis)
        self._update_utxo_set(genesis)
        self._save_to_disk()
    
    def _load_from_disk(self):
        """Carga la blockchain desde disco"""
        chain_file = os.path.join(self.data_dir, "chain.json")
        
        with open(chain_file, 'r') as f:
            chain_data = json.load(f)
        
        for block_data in chain_data["blocks"]:
            block = Block.from_dict(block_data)
            self.chain.append(block)
            self._update_indices(block)
            self._update_utxo_set(block)
    
    def _save_to_disk(self):
        """Guarda la blockchain en disco"""
        chain_file = os.path.join(self.data_dir, "chain.json")
        
        chain_data = {
            "blocks": [block.to_dict() for block in self.chain]
        }
        
        with open(chain_file, 'w') as f:
            json.dump(chain_data, f, indent=2)
    
    def _update_indices(self, block: Block):
        """Actualiza los índices de búsqueda"""
        self.block_index[block.block_hash] = block
        self.height_index[block.height] = block
    
    def _update_utxo_set(self, block: Block):
        """Actualiza el UTXO set con las transacciones del bloque"""
        for tx in block.transactions:
            # Remover inputs gastados (excepto coinbase)
            if not tx.is_coinbase() and not tx.is_stake():
                for inp in tx.inputs:
                    utxo_key = f"{inp.tx_id}:{inp.output_index}"
                    if utxo_key in self.utxo_set:
                        del self.utxo_set[utxo_key]
            
            # Añadir nuevos outputs
            for i, output in enumerate(tx.outputs):
                utxo_key = f"{tx.tx_id}:{i}"
                self.utxo_set[utxo_key] = {
                    "amount": output.amount,
                    "address": output.address,
                    "tx_id": tx.tx_id,
                    "output_index": i
                }
    
    def get_latest_block(self) -> Block:
        """Retorna el último bloque de la cadena"""
        return self.chain[-1] if self.chain else None
    
    def get_block_by_hash(self, block_hash: str) -> Optional[Block]:
        """Obtiene un bloque por su hash"""
        return self.block_index.get(block_hash)
    
    def get_block_by_height(self, height: int) -> Optional[Block]:
        """Obtiene un bloque por su altura"""
        return self.height_index.get(height)
    
    def get_height(self) -> int:
        """Retorna la altura actual de la cadena"""
        return len(self.chain) - 1
    
    def get_difficulty(self) -> int:
        """Calcula la dificultad actual"""
        height = self.get_height()
        
        # Ajustar dificultad cada DIFFICULTY_ADJUSTMENT_INTERVAL bloques
        if height % self.DIFFICULTY_ADJUSTMENT_INTERVAL != 0:
            return self.get_latest_block().header.difficulty
        
        # Calcular tiempo transcurrido en los últimos N bloques
        if height < self.DIFFICULTY_ADJUSTMENT_INTERVAL:
            return self.INITIAL_DIFFICULTY
        
        start_block = self.get_block_by_height(height - self.DIFFICULTY_ADJUSTMENT_INTERVAL)
        end_block = self.get_latest_block()
        
        time_taken = end_block.header.timestamp - start_block.header.timestamp
        time_expected = self.BLOCK_TIME_TARGET * self.DIFFICULTY_ADJUSTMENT_INTERVAL
        
        # Ajustar dificultad
        current_difficulty = end_block.header.difficulty
        
        if time_taken < time_expected / 2:
            # Muy rápido, aumentar dificultad
            return current_difficulty + 1
        elif time_taken > time_expected * 2:
            # Muy lento, disminuir dificultad
            return max(1, current_difficulty - 1)
        else:
            return current_difficulty
    
    def get_block_reward(self, height: int) -> float:
        """Calcula la recompensa del bloque según la altura"""
        halvings = height // self.HALVING_INTERVAL
        reward = self.INITIAL_REWARD / (2 ** halvings)
        return max(0, reward)
    
    def get_next_block_type(self) -> str:
        """Determina si el siguiente bloque debe ser PoW o PoS"""
        height = self.get_height() + 1
        position_in_cycle = height % self.CYCLE_LENGTH
        
        # Primeros 7 bloques del ciclo son PoW, siguientes 3 son PoS
        if position_in_cycle < self.POW_CYCLE_LENGTH:
            return "pow"
        else:
            return "pos"
    
    def validate_block(self, block: Block) -> Tuple[bool, str]:
        """Valida un bloque completo"""
        # Validación básica
        if not block.validate_basic():
            return False, "Validación básica falló"
        
        # Verificar que el bloque anterior exista
        if block.header.previous_hash != "0" * 64:  # No es génesis
            previous_block = self.get_block_by_hash(block.header.previous_hash)
            if not previous_block:
                return False, "Bloque anterior no encontrado"
            
            # Verificar altura
            if block.height != previous_block.height + 1:
                return False, "Altura incorrecta"
        
        # Verificar tipo de bloque (PoW o PoS según ciclo)
        expected_type = self.get_next_block_type()
        if block.header.block_type != expected_type:
            return False, f"Tipo de bloque incorrecto, esperado {expected_type}"
        
        # Verificar dificultad
        expected_difficulty = self.get_difficulty()
        if block.header.difficulty != expected_difficulty:
            return False, "Dificultad incorrecta"
        
        # Verificar recompensa
        expected_reward = self.get_block_reward(block.height)
        actual_reward = block.transactions[0].get_output_sum()
        
        # Calcular fees totales
        total_fees = 0.0
        for tx in block.transactions[1:]:
            total_fees += tx.get_fee(self.utxo_set)
        
        if actual_reward > expected_reward + total_fees:
            return False, "Recompensa excesiva"
        
        # Validar todas las transacciones
        if not block.validate_transactions(self.utxo_set):
            return False, "Transacciones inválidas"
        
        return True, "Bloque válido"
    
    def add_block(self, block: Block) -> bool:
        """Añade un bloque a la cadena"""
        # Validar bloque
        is_valid, message = self.validate_block(block)
        if not is_valid:
            print(f"Bloque rechazado: {message}")
            return False
        
        # Añadir a la cadena
        self.chain.append(block)
        self._update_indices(block)
        self._update_utxo_set(block)
        
        # Remover transacciones del pool
        for tx in block.transactions:
            self.transaction_pool.remove_transaction(tx.tx_id)
        
        # Guardar en disco
        self._save_to_disk()
        
        return True
    
    def add_transaction(self, tx: Transaction) -> bool:
        """Añade una transacción al pool"""
        return self.transaction_pool.add_transaction(tx, self.utxo_set)
    
    def get_balance(self, address: str) -> float:
        """Calcula el balance de una dirección"""
        balance = 0.0
        
        for utxo_key, utxo in self.utxo_set.items():
            if utxo["address"] == address:
                balance += utxo["amount"]
        
        return balance
    
    def get_utxos_for_address(self, address: str) -> List[Dict]:
        """Obtiene todos los UTXOs de una dirección"""
        utxos = []
        
        for utxo_key, utxo in self.utxo_set.items():
            if utxo["address"] == address:
                utxos.append({
                    "key": utxo_key,
                    **utxo
                })
        
        return utxos
    
    def get_transaction_history(self, address: str) -> List[Dict]:
        """Obtiene el historial de transacciones de una dirección"""
        history = []
        
        for block in self.chain:
            for tx in block.transactions:
                involved = False
                amount = 0.0
                tx_type = "received"
                
                # Verificar si la dirección está en los outputs
                for output in tx.outputs:
                    if output.address == address:
                        involved = True
                        amount += output.amount
                
                # Verificar si la dirección está en los inputs
                for inp in tx.inputs:
                    utxo_key = f"{inp.tx_id}:{inp.output_index}"
                    # Buscar en blockchain histórica
                    # (simplificado, en producción buscaríamos en la tx referenciada)
                    if involved:
                        tx_type = "sent"
                
                if involved:
                    history.append({
                        "tx_id": tx.tx_id,
                        "type": tx_type,
                        "amount": amount,
                        "timestamp": tx.timestamp,
                        "block_height": block.height
                    })
        
        return history
    
    def get_network_stats(self) -> Dict:
        """Obtiene estadísticas de la red"""
        total_supply = 0.0
        for utxo in self.utxo_set.values():
            total_supply += utxo["amount"]
        
        return {
            "height": self.get_height(),
            "difficulty": self.get_difficulty(),
            "total_supply": total_supply,
            "max_supply": self.MAX_SUPPLY,
            "block_reward": self.get_block_reward(self.get_height() + 1),
            "mempool_size": self.transaction_pool.size(),
            "utxo_count": len(self.utxo_set)
        }
    
    def __repr__(self) -> str:
        return f"Blockchain(height={self.get_height()}, difficulty={self.get_difficulty()})"
