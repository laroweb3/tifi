"""
TIFI Blockchain - Transaction Module
Maneja la creación, validación y firma de transacciones
"""

import hashlib
import json
import time
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict


@dataclass
class TransactionInput:
    """Input de una transacción (referencia a output previo)"""
    tx_id: str  # ID de transacción previa
    output_index: int  # Índice del output en la transacción previa
    signature: str = ""  # Firma del propietario
    public_key: str = ""  # Clave pública del propietario
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


@dataclass
class TransactionOutput:
    """Output de una transacción (destino y cantidad)"""
    address: str  # Dirección destino
    amount: float  # Cantidad de CRED
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class Transaction:
    """Transacción en la blockchain TIFI"""
    
    def __init__(
        self,
        inputs: List[TransactionInput],
        outputs: List[TransactionOutput],
        timestamp: Optional[float] = None,
        tx_type: str = "regular"  # regular, coinbase, stake
    ):
        self.inputs = inputs
        self.outputs = outputs
        self.timestamp = timestamp or time.time()
        self.tx_type = tx_type
        self.tx_id = self.calculate_hash()
    
    def calculate_hash(self) -> str:
        """Calcula el hash único de la transacción"""
        tx_data = {
            "inputs": [inp.to_dict() for inp in self.inputs],
            "outputs": [out.to_dict() for out in self.outputs],
            "timestamp": self.timestamp,
            "type": self.tx_type
        }
        tx_string = json.dumps(tx_data, sort_keys=True)
        return hashlib.sha256(tx_string.encode()).hexdigest()
    
    def get_input_sum(self) -> float:
        """Suma total de inputs (requiere acceso a UTXO set)"""
        # Esto se calculará con acceso al UTXO set en la blockchain
        return 0.0
    
    def get_output_sum(self) -> float:
        """Suma total de outputs"""
        return sum(output.amount for output in self.outputs)
    
    def get_fee(self, utxo_set: Dict) -> float:
        """Calcula el fee de la transacción"""
        if self.tx_type == "coinbase":
            return 0.0
        
        input_sum = 0.0
        for inp in self.inputs:
            utxo_key = f"{inp.tx_id}:{inp.output_index}"
            if utxo_key in utxo_set:
                input_sum += utxo_set[utxo_key]["amount"]
        
        output_sum = self.get_output_sum()
        return input_sum - output_sum
    
    def is_coinbase(self) -> bool:
        """Verifica si es una transacción coinbase (recompensa de minería)"""
        return self.tx_type == "coinbase"
    
    def is_stake(self) -> bool:
        """Verifica si es una transacción de stake"""
        return self.tx_type == "stake"
    
    def validate_basic(self) -> bool:
        """Validación básica de la transacción"""
        # Verificar que no esté vacía
        if not self.outputs:
            return False
        
        # Coinbase debe tener exactamente 0 inputs
        if self.is_coinbase():
            if len(self.inputs) != 0:
                return False
        else:
            # Transacciones regulares deben tener inputs
            if len(self.inputs) == 0:
                return False
        
        # Verificar que los outputs sean positivos
        for output in self.outputs:
            if output.amount <= 0:
                return False
        
        # Verificar que el hash sea correcto
        if self.tx_id != self.calculate_hash():
            return False
        
        return True
    
    def validate_full(self, utxo_set: Dict) -> bool:
        """Validación completa de la transacción (requiere UTXO set)"""
        if not self.validate_basic():
            return False
        
        # Coinbase no necesita validación de inputs
        if self.is_coinbase():
            return True
        
        # Verificar que todos los inputs existan en UTXO set
        input_sum = 0.0
        for inp in self.inputs:
            utxo_key = f"{inp.tx_id}:{inp.output_index}"
            if utxo_key not in utxo_set:
                return False  # Input no existe (ya gastado o inválido)
            
            utxo = utxo_set[utxo_key]
            input_sum += utxo["amount"]
            
            # Verificar firma (se implementará con crypto module)
            # TODO: Verificar que inp.signature sea válida con inp.public_key
        
        # Verificar que inputs >= outputs (el resto es fee)
        output_sum = self.get_output_sum()
        if input_sum < output_sum:
            return False  # Intentando gastar más de lo que tiene
        
        return True
    
    def to_dict(self) -> Dict:
        """Convierte la transacción a diccionario"""
        return {
            "tx_id": self.tx_id,
            "inputs": [inp.to_dict() for inp in self.inputs],
            "outputs": [out.to_dict() for out in self.outputs],
            "timestamp": self.timestamp,
            "type": self.tx_type
        }
    
    @classmethod
    def from_dict(cls, data: Dict):
        """Crea una transacción desde un diccionario"""
        inputs = [TransactionInput.from_dict(inp) for inp in data["inputs"]]
        outputs = [TransactionOutput.from_dict(out) for out in data["outputs"]]
        tx = cls(
            inputs=inputs,
            outputs=outputs,
            timestamp=data["timestamp"],
            tx_type=data.get("type", "regular")
        )
        tx.tx_id = data["tx_id"]
        return tx
    
    @staticmethod
    def create_coinbase(miner_address: str, reward: float, block_height: int) -> 'Transaction':
        """Crea una transacción coinbase (recompensa de minería)"""
        output = TransactionOutput(address=miner_address, amount=reward)
        tx = Transaction(
            inputs=[],
            outputs=[output],
            tx_type="coinbase"
        )
        return tx
    
    @staticmethod
    def create_stake_reward(staker_address: str, reward: float) -> 'Transaction':
        """Crea una transacción de recompensa de stake"""
        output = TransactionOutput(address=staker_address, amount=reward)
        tx = Transaction(
            inputs=[],
            outputs=[output],
            tx_type="stake"
        )
        return tx
    
    def __repr__(self) -> str:
        return f"Transaction(id={self.tx_id[:8]}..., type={self.tx_type}, outputs={len(self.outputs)})"


class TransactionPool:
    """Pool de transacciones pendientes (mempool)"""
    
    def __init__(self):
        self.transactions: Dict[str, Transaction] = {}
    
    def add_transaction(self, tx: Transaction, utxo_set: Dict) -> bool:
        """Añade una transacción al pool si es válida"""
        # Validar transacción
        if not tx.validate_full(utxo_set):
            return False
        
        # Verificar que no esté duplicada
        if tx.tx_id in self.transactions:
            return False
        
        # Verificar que no haya conflictos (double-spending)
        for inp in tx.inputs:
            utxo_key = f"{inp.tx_id}:{inp.output_index}"
            # Verificar que ninguna otra transacción en el pool use este input
            for existing_tx in self.transactions.values():
                for existing_inp in existing_tx.inputs:
                    existing_key = f"{existing_inp.tx_id}:{existing_inp.output_index}"
                    if utxo_key == existing_key:
                        return False  # Conflicto detectado
        
        # Añadir al pool
        self.transactions[tx.tx_id] = tx
        return True
    
    def remove_transaction(self, tx_id: str):
        """Elimina una transacción del pool"""
        if tx_id in self.transactions:
            del self.transactions[tx_id]
    
    def get_transactions(self, max_count: int = 2000) -> List[Transaction]:
        """Obtiene transacciones del pool ordenadas por fee"""
        # Ordenar por fee (mayor primero)
        # Por ahora retornamos en orden de llegada
        txs = list(self.transactions.values())
        return txs[:max_count]
    
    def clear(self):
        """Limpia el pool"""
        self.transactions.clear()
    
    def size(self) -> int:
        """Retorna el tamaño del pool"""
        return len(self.transactions)
    
    def __repr__(self) -> str:
        return f"TransactionPool(size={self.size()})"
