"""
TIFI Blockchain - CPU Miner
Minero optimizado para CPU con multi-threading
"""

import time
import threading
import multiprocessing
from typing import Optional, Callable
from datetime import datetime


class CPUMiner:
    """Minero CPU para TIFI"""
    
    def __init__(self, blockchain, wallet, consensus):
        self.blockchain = blockchain
        self.wallet = wallet
        self.consensus = consensus
        
        self.mining = False
        self.mining_thread: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()
        
        # Estadísticas
        self.blocks_found = 0
        self.total_hashes = 0
        self.start_time = 0.0
        self.current_hashrate = 0.0
        
        # Configuración
        self.threads = multiprocessing.cpu_count()
        self.mining_address = None
    
    def set_mining_address(self, address: str):
        """Establece la dirección para recibir recompensas"""
        self.mining_address = address
    
    def start(self, address: Optional[str] = None):
        """Inicia la minería"""
        if self.mining:
            print("Minería ya está en ejecución")
            return
        
        # Establecer dirección de minería
        if address:
            self.mining_address = address
        elif not self.mining_address:
            # Generar nueva dirección si no hay una
            self.mining_address = self.wallet.get_new_address("Mining")
        
        print(f"Iniciando minería en {self.threads} threads...")
        print(f"Dirección de minería: {self.mining_address}")
        
        self.mining = True
        self.stop_flag.clear()
        self.start_time = time.time()
        
        # Iniciar thread de minería
        self.mining_thread = threading.Thread(target=self._mining_loop, daemon=True)
        self.mining_thread.start()
        
        print("✓ Minería iniciada")
    
    def stop(self):
        """Detiene la minería"""
        if not self.mining:
            return
        
        print("Deteniendo minería...")
        self.mining = False
        self.stop_flag.set()
        
        if self.mining_thread:
            self.mining_thread.join(timeout=5)
        
        print("✓ Minería detenida")
    
    def _mining_loop(self):
        """Loop principal de minería"""
        while self.mining:
            try:
                # Verificar si debemos minar un bloque PoW
                next_block_type = self.blockchain.get_next_block_type()
                
                if next_block_type != "pow":
                    # No es nuestro turno, esperar
                    time.sleep(10)
                    continue
                
                # Obtener transacciones del mempool
                transactions = self.blockchain.transaction_pool.get_transactions(500)
                
                # Crear bloque candidato
                block = self.consensus.create_next_block(
                    miner_address=self.mining_address,
                    transactions=transactions
                )
                
                if not block:
                    time.sleep(5)
                    continue
                
                print(f"\n[Minero] Minando bloque #{block.height}")
                print(f"  Dificultad: {block.header.difficulty}")
                print(f"  Transacciones: {len(block.transactions)}")
                print(f"  Recompensa: {block.transactions[0].get_output_sum():.2f} CRED")
                
                # Minar el bloque
                start_time = time.time()
                success = self.consensus.mine_block(block, lambda: self.stop_flag.is_set())
                
                if success and not self.stop_flag.is_set():
                    # Bloque minado exitosamente
                    elapsed = time.time() - start_time
                    
                    # Añadir a la blockchain
                    if self.blockchain.add_block(block):
                        self.blocks_found += 1
                        
                        print(f"\n{'='*60}")
                        print(f"  🎉 ¡BLOQUE MINADO! 🎉")
                        print(f"{'='*60}")
                        print(f"  Altura: {block.height}")
                        print(f"  Hash: {block.block_hash}")
                        print(f"  Tiempo: {elapsed:.2f}s")
                        print(f"  Recompensa: {block.transactions[0].get_output_sum():.2f} CRED")
                        print(f"  Total bloques encontrados: {self.blocks_found}")
                        print(f"{'='*60}\n")
                        
                        # TODO: Broadcast del bloque a la red
                    else:
                        print("✗ Bloque rechazado por la blockchain")
                
                elif self.stop_flag.is_set():
                    print("Minería interrumpida")
                    break
                else:
                    # Otro minero encontró el bloque primero
                    print("✗ Bloque obsoleto, reiniciando...")
            
            except Exception as e:
                print(f"Error en minería: {e}")
                time.sleep(5)
    
    def get_hashrate(self) -> float:
        """Calcula el hashrate actual (estimado)"""
        if not self.mining or self.start_time == 0:
            return 0.0
        
        elapsed = time.time() - self.start_time
        if elapsed == 0:
            return 0.0
        
        # Estimación basada en dificultad y tiempo
        # En una implementación real, contaríamos hashes reales
        difficulty = self.blockchain.get_difficulty()
        estimated_hashes = (2 ** difficulty) * self.blocks_found
        
        return estimated_hashes / elapsed if elapsed > 0 else 0.0
    
    def get_stats(self) -> dict:
        """Obtiene estadísticas de minería"""
        uptime = time.time() - self.start_time if self.start_time > 0 else 0
        
        return {
            "mining": self.mining,
            "mining_address": self.mining_address,
            "threads": self.threads,
            "blocks_found": self.blocks_found,
            "hashrate": self.get_hashrate(),
            "uptime": uptime,
            "difficulty": self.blockchain.get_difficulty(),
            "next_block_type": self.blockchain.get_next_block_type()
        }
    
    def is_mining(self) -> bool:
        """Verifica si está minando"""
        return self.mining
    
    def __repr__(self) -> str:
        status = "ACTIVO" if self.mining else "INACTIVO"
        return f"CPUMiner(status={status}, blocks={self.blocks_found}, hashrate={self.get_hashrate():.2f} H/s)"


class MiningPool:
    """Pool de minería (para futuras implementaciones)"""
    
    def __init__(self, pool_url: str, username: str):
        self.pool_url = pool_url
        self.username = username
        self.connected = False
    
    def connect(self):
        """Conecta al pool"""
        # TODO: Implementar conexión a pool
        pass
    
    def disconnect(self):
        """Desconecta del pool"""
        # TODO: Implementar desconexión
        pass
    
    def submit_share(self, block_data: dict):
        """Envía un share al pool"""
        # TODO: Implementar envío de shares
        pass


class MiningManager:
    """Gestor de minería que coordina mineros y pools"""
    
    def __init__(self, blockchain, wallet, consensus):
        self.blockchain = blockchain
        self.wallet = wallet
        self.consensus = consensus
        
        self.solo_miner = CPUMiner(blockchain, wallet, consensus)
        self.pool_miner: Optional[MiningPool] = None
        self.mode = "solo"  # solo o pool
    
    def start_solo_mining(self, address: Optional[str] = None):
        """Inicia minería en solitario"""
        self.mode = "solo"
        self.solo_miner.start(address)
    
    def start_pool_mining(self, pool_url: str, username: str):
        """Inicia minería en pool"""
        self.mode = "pool"
        self.pool_miner = MiningPool(pool_url, username)
        self.pool_miner.connect()
        # TODO: Implementar minería en pool
    
    def stop_mining(self):
        """Detiene toda minería"""
        if self.mode == "solo":
            self.solo_miner.stop()
        elif self.mode == "pool" and self.pool_miner:
            self.pool_miner.disconnect()
    
    def is_mining(self) -> bool:
        """Verifica si está minando"""
        if self.mode == "solo":
            return self.solo_miner.is_mining()
        elif self.mode == "pool" and self.pool_miner:
            return self.pool_miner.connected
        return False
    
    def get_stats(self) -> dict:
        """Obtiene estadísticas de minería"""
        if self.mode == "solo":
            stats = self.solo_miner.get_stats()
            stats["mode"] = "solo"
            return stats
        elif self.mode == "pool" and self.pool_miner:
            return {
                "mode": "pool",
                "pool_url": self.pool_miner.pool_url,
                "connected": self.pool_miner.connected
            }
        return {"mode": "none", "mining": False}
    
    def set_threads(self, threads: int):
        """Establece el número de threads para minería"""
        self.solo_miner.threads = threads
    
    def __repr__(self) -> str:
        return f"MiningManager(mode={self.mode}, mining={self.is_mining()})"
