"""
TIFI Blockchain - Wallet Module
Gestión completa del wallet: claves, transacciones, balance
"""

import json
import os
from typing import List, Dict, Optional, Tuple
from keys import KeyManager
from crypto import TIFICrypto, sign_transaction_data


class Wallet:
    """Wallet TIFI completo"""
    
    def __init__(self, blockchain, data_dir: str = "~/.tifi"):
        self.blockchain = blockchain
        self.data_dir = os.path.expanduser(data_dir)
        self.wallet_file = os.path.join(self.data_dir, "wallet.json")
        
        self.key_manager = KeyManager()
        self.label_map: Dict[str, str] = {}  # address -> label
        
        # Cargar wallet si existe
        self._load_wallet()
    
    def _load_wallet(self):
        """Carga el wallet desde disco"""
        if os.path.exists(self.wallet_file):
            try:
                with open(self.wallet_file, 'r') as f:
                    data = json.load(f)
                
                # Restaurar wallet HD si existe
                if "mnemonic" in data:
                    # En producción, esto debería estar encriptado
                    self.key_manager.restore_wallet(data["mnemonic"])
                    self.key_manager.address_index = data.get("address_index", 0)
                
                # Cargar claves importadas
                if "imported_keys" in data:
                    for address, private_key_hex in data["imported_keys"].items():
                        private_key = bytes.fromhex(private_key_hex)
                        self.key_manager.imported_keys[address] = private_key
                
                # Cargar etiquetas
                self.label_map = data.get("labels", {})
                
                print(f"✓ Wallet cargado: {self.key_manager.address_index} direcciones")
            
            except Exception as e:
                print(f"Error cargando wallet: {e}")
    
    def _save_wallet(self):
        """Guarda el wallet en disco"""
        data = {
            "version": 1,
            "labels": self.label_map
        }
        
        # Guardar wallet HD
        if self.key_manager.has_wallet():
            # ADVERTENCIA: En producción, el mnemonic debe estar encriptado
            data["mnemonic"] = self.key_manager.hd_wallet.get_mnemonic()
            data["address_index"] = self.key_manager.address_index
        
        # Guardar claves importadas
        if self.key_manager.imported_keys:
            data["imported_keys"] = {
                addr: key.hex() for addr, key in self.key_manager.imported_keys.items()
            }
        
        # Guardar en disco
        os.makedirs(self.data_dir, exist_ok=True)
        with open(self.wallet_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def create_new_wallet(self) -> str:
        """
        Crea un nuevo wallet
        
        Returns:
            Mnemonic phrase (DEBE GUARDARSE EN LUGAR SEGURO)
        """
        mnemonic = self.key_manager.create_new_wallet()
        self._save_wallet()
        return mnemonic
    
    def restore_from_mnemonic(self, mnemonic: str):
        """Restaura el wallet desde un mnemonic"""
        self.key_manager.restore_wallet(mnemonic)
        self._save_wallet()
    
    def get_new_address(self, label: str = "") -> str:
        """
        Genera una nueva dirección
        
        Args:
            label: Etiqueta opcional para la dirección
        
        Returns:
            Nueva dirección TIFI
        """
        address = self.key_manager.get_new_address()
        
        if label:
            self.label_map[address] = label
        
        self._save_wallet()
        return address
    
    def get_all_addresses(self) -> List[str]:
        """Obtiene todas las direcciones del wallet"""
        addresses = []
        
        # Direcciones del wallet HD
        if self.key_manager.has_wallet():
            addresses.extend(self.key_manager.get_addresses(self.key_manager.address_index))
        
        # Direcciones importadas
        addresses.extend(self.key_manager.imported_keys.keys())
        
        return addresses
    
    def get_balance(self, address: Optional[str] = None) -> float:
        """
        Obtiene el balance
        
        Args:
            address: Dirección específica, o None para balance total
        
        Returns:
            Balance en CRED
        """
        if address:
            return self.blockchain.get_balance(address)
        else:
            # Balance total de todas las direcciones
            total = 0.0
            for addr in self.get_all_addresses():
                total += self.blockchain.get_balance(addr)
            return total
    
    def get_balance_details(self) -> List[Dict]:
        """Obtiene balance detallado de todas las direcciones"""
        details = []
        
        for address in self.get_all_addresses():
            balance = self.blockchain.get_balance(address)
            if balance > 0 or address in self.label_map:
                details.append({
                    "address": address,
                    "balance": balance,
                    "label": self.label_map.get(address, "")
                })
        
        return details
    
    def create_transaction(
        self,
        to_address: str,
        amount: float,
        fee: float = 0.001,
        from_address: Optional[str] = None
    ) -> Optional['Transaction']:
        """
        Crea una transacción
        
        Args:
            to_address: Dirección destino
            amount: Cantidad a enviar
            fee: Fee de la transacción
            from_address: Dirección origen (opcional, se selecciona automáticamente)
        
        Returns:
            Transacción creada o None si no hay fondos suficientes
        """
        from transaction import Transaction, TransactionInput, TransactionOutput
        
        # Validar dirección destino
        if not TIFICrypto.validate_address(to_address):
            print("Dirección destino inválida")
            return None
        
        # Seleccionar UTXOs
        utxos_to_use, change_amount = self._select_utxos(amount + fee, from_address)
        
        if not utxos_to_use:
            print("Fondos insuficientes")
            return None
        
        # Crear inputs
        inputs = []
        for utxo in utxos_to_use:
            tx_input = TransactionInput(
                tx_id=utxo["tx_id"],
                output_index=utxo["output_index"]
            )
            inputs.append(tx_input)
        
        # Crear outputs
        outputs = [
            TransactionOutput(address=to_address, amount=amount)
        ]
        
        # Añadir cambio si es necesario
        if change_amount > 0:
            # Usar la primera dirección con UTXOs como dirección de cambio
            change_address = utxos_to_use[0]["address"]
            outputs.append(TransactionOutput(address=change_address, amount=change_amount))
        
        # Crear transacción
        tx = Transaction(inputs=inputs, outputs=outputs)
        
        # Firmar inputs
        for i, tx_input in enumerate(inputs):
            utxo = utxos_to_use[i]
            address = utxo["address"]
            
            # Obtener clave privada
            private_key = self.key_manager.get_private_key_for_address(address)
            if not private_key:
                print(f"No se encontró clave privada para {address}")
                return None
            
            # Crear datos a firmar
            tx_data = tx.calculate_hash()
            
            # Firmar
            signature = sign_transaction_data(private_key, tx_data)
            public_key = TIFICrypto.private_key_to_public_key(private_key)
            
            # Añadir firma al input
            tx_input.signature = signature
            tx_input.public_key = TIFICrypto.public_key_to_hex(public_key)
        
        # Recalcular hash después de firmar
        tx.tx_id = tx.calculate_hash()
        
        return tx
    
    def _select_utxos(self, amount_needed: float, from_address: Optional[str] = None) -> Tuple[List[Dict], float]:
        """
        Selecciona UTXOs para una transacción
        
        Returns:
            (utxos_selected, change_amount)
        """
        # Obtener UTXOs disponibles
        available_utxos = []
        
        if from_address:
            # Solo de una dirección específica
            utxos = self.blockchain.get_utxos_for_address(from_address)
            available_utxos.extend(utxos)
        else:
            # De todas las direcciones del wallet
            for address in self.get_all_addresses():
                utxos = self.blockchain.get_utxos_for_address(address)
                available_utxos.extend(utxos)
        
        # Ordenar por cantidad (mayor primero)
        available_utxos.sort(key=lambda x: x["amount"], reverse=True)
        
        # Selección simple: tomar UTXOs hasta cubrir el monto
        selected = []
        total = 0.0
        
        for utxo in available_utxos:
            selected.append(utxo)
            total += utxo["amount"]
            
            if total >= amount_needed:
                break
        
        if total < amount_needed:
            return [], 0.0
        
        change = total - amount_needed
        return selected, change
    
    def send_transaction(self, tx) -> bool:
        """Envía una transacción a la red"""
        # Añadir a mempool
        if self.blockchain.add_transaction(tx):
            print(f"✓ Transacción enviada: {tx.tx_id}")
            return True
        else:
            print(f"✗ Error enviando transacción")
            return False
    
    def send(self, to_address: str, amount: float, fee: float = 0.001) -> bool:
        """
        Envía CRED a una dirección (función de conveniencia)
        
        Returns:
            True si la transacción fue exitosa
        """
        tx = self.create_transaction(to_address, amount, fee)
        
        if tx:
            return self.send_transaction(tx)
        
        return False
    
    def get_transaction_history(self, address: Optional[str] = None) -> List[Dict]:
        """Obtiene el historial de transacciones"""
        if address:
            return self.blockchain.get_transaction_history(address)
        else:
            # Historial de todas las direcciones
            all_history = []
            seen_txs = set()
            
            for addr in self.get_all_addresses():
                history = self.blockchain.get_transaction_history(addr)
                for tx in history:
                    if tx["tx_id"] not in seen_txs:
                        all_history.append(tx)
                        seen_txs.add(tx["tx_id"])
            
            # Ordenar por timestamp
            all_history.sort(key=lambda x: x["timestamp"], reverse=True)
            return all_history
    
    def import_private_key(self, private_key_or_wif: str, label: str = "") -> str:
        """
        Importa una clave privada
        
        Args:
            private_key_or_wif: Clave privada en hex o WIF
            label: Etiqueta opcional
        
        Returns:
            Dirección importada
        """
        try:
            # Intentar como WIF primero
            address = self.key_manager.import_wif(private_key_or_wif)
        except:
            # Intentar como hex
            try:
                private_key = bytes.fromhex(private_key_or_wif)
                address = self.key_manager.import_private_key(private_key)
            except:
                raise ValueError("Formato de clave privada inválido")
        
        if label:
            self.label_map[address] = label
        
        self._save_wallet()
        return address
    
    def export_private_key(self, address: str, format: str = 'hex') -> Optional[str]:
        """Exporta una clave privada"""
        return self.key_manager.export_private_key(address, format)
    
    def set_label(self, address: str, label: str):
        """Establece una etiqueta para una dirección"""
        self.label_map[address] = label
        self._save_wallet()
    
    def get_label(self, address: str) -> str:
        """Obtiene la etiqueta de una dirección"""
        return self.label_map.get(address, "")
    
    def get_wallet_info(self) -> Dict:
        """Obtiene información del wallet"""
        return {
            "initialized": self.key_manager.has_wallet(),
            "addresses": len(self.get_all_addresses()),
            "balance": self.get_balance(),
            "key_manager": self.key_manager.get_wallet_info()
        }
    
    def backup_wallet(self, backup_path: str):
        """Crea un backup del wallet"""
        import shutil
        shutil.copy(self.wallet_file, backup_path)
        print(f"✓ Backup creado en {backup_path}")
    
    def __repr__(self) -> str:
        return f"Wallet(addresses={len(self.get_all_addresses())}, balance={self.get_balance():.2f} CRED)"
