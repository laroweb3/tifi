"""
TIFI Blockchain - HD Keys Module
Generación de claves jerárquicas determinísticas (BIP39/BIP44)
"""

import hashlib
import hmac
from mnemonic import Mnemonic
from typing import List, Tuple, Optional
from crypto import TIFICrypto


class HDKey:
    """Clave jerárquica determinística"""
    
    def __init__(self, private_key: bytes, chain_code: bytes, depth: int = 0, index: int = 0):
        self.private_key = private_key
        self.chain_code = chain_code
        self.depth = depth
        self.index = index
        self.public_key = TIFICrypto.private_key_to_public_key(private_key)
    
    def derive_child(self, index: int, hardened: bool = False) -> 'HDKey':
        """
        Deriva una clave hija
        
        Args:
            index: Índice de la clave hija
            hardened: Si es derivación hardened
        
        Returns:
            Nueva HDKey derivada
        """
        if hardened:
            # Derivación hardened usa clave privada
            index_bytes = (index + 0x80000000).to_bytes(4, 'big')
            data = b'\x00' + self.private_key + index_bytes
        else:
            # Derivación normal usa clave pública
            index_bytes = index.to_bytes(4, 'big')
            data = self.public_key + index_bytes
        
        # HMAC-SHA512
        hmac_result = hmac.new(self.chain_code, data, hashlib.sha512).digest()
        
        # Dividir resultado
        left = hmac_result[:32]
        right = hmac_result[32:]
        
        # Nueva clave privada = (left + parent_key) mod n
        # Simplificado: solo usamos left como nueva clave
        child_private_key = left
        child_chain_code = right
        
        return HDKey(
            private_key=child_private_key,
            chain_code=child_chain_code,
            depth=self.depth + 1,
            index=index
        )
    
    def get_address(self) -> str:
        """Obtiene la dirección TIFI de esta clave"""
        return TIFICrypto.public_key_to_address(self.public_key)


class HDWallet:
    """Wallet HD (Hierarchical Deterministic)"""
    
    # BIP44 path: m/44'/coin_type'/account'/change/address_index
    COIN_TYPE = 8333  # Coin type para TIFI
    
    def __init__(self, mnemonic_phrase: Optional[str] = None, language: str = 'english'):
        self.mnemo = Mnemonic(language)
        
        if mnemonic_phrase:
            # Cargar desde mnemonic existente
            if not self.mnemo.check(mnemonic_phrase):
                raise ValueError("Mnemonic phrase inválido")
            self.mnemonic_phrase = mnemonic_phrase
        else:
            # Generar nuevo mnemonic
            self.mnemonic_phrase = self.mnemo.generate(strength=256)  # 24 palabras
        
        # Generar seed desde mnemonic
        self.seed = self.mnemo.to_seed(self.mnemonic_phrase, passphrase="")
        
        # Generar master key
        self.master_key = self._generate_master_key()
    
    def _generate_master_key(self) -> HDKey:
        """Genera la clave maestra desde el seed"""
        # HMAC-SHA512 con "Bitcoin seed" (estándar BIP32)
        hmac_result = hmac.new(b"Bitcoin seed", self.seed, hashlib.sha512).digest()
        
        # Dividir resultado
        master_private_key = hmac_result[:32]
        master_chain_code = hmac_result[32:]
        
        return HDKey(master_private_key, master_chain_code, depth=0, index=0)
    
    def derive_account_key(self, account: int = 0) -> HDKey:
        """
        Deriva la clave de cuenta según BIP44
        Path: m/44'/coin_type'/account'
        """
        # m/44'
        purpose_key = self.master_key.derive_child(44, hardened=True)
        
        # m/44'/coin_type'
        coin_key = purpose_key.derive_child(self.COIN_TYPE, hardened=True)
        
        # m/44'/coin_type'/account'
        account_key = coin_key.derive_child(account, hardened=True)
        
        return account_key
    
    def derive_address_key(self, account: int = 0, change: int = 0, index: int = 0) -> HDKey:
        """
        Deriva una clave de dirección según BIP44
        Path: m/44'/coin_type'/account'/change/index
        
        Args:
            account: Número de cuenta
            change: 0 para direcciones externas, 1 para cambio
            index: Índice de la dirección
        """
        account_key = self.derive_account_key(account)
        
        # m/44'/coin_type'/account'/change
        change_key = account_key.derive_child(change, hardened=False)
        
        # m/44'/coin_type'/account'/change/index
        address_key = change_key.derive_child(index, hardened=False)
        
        return address_key
    
    def get_address(self, account: int = 0, change: int = 0, index: int = 0) -> str:
        """Obtiene una dirección derivada"""
        key = self.derive_address_key(account, change, index)
        return key.get_address()
    
    def get_private_key(self, account: int = 0, change: int = 0, index: int = 0) -> bytes:
        """Obtiene la clave privada de una dirección derivada"""
        key = self.derive_address_key(account, change, index)
        return key.private_key
    
    def get_multiple_addresses(self, count: int = 10, account: int = 0, change: int = 0) -> List[Tuple[int, str, bytes]]:
        """
        Genera múltiples direcciones
        
        Returns:
            Lista de (index, address, private_key)
        """
        addresses = []
        
        for i in range(count):
            key = self.derive_address_key(account, change, i)
            addresses.append((i, key.get_address(), key.private_key))
        
        return addresses
    
    def get_mnemonic(self) -> str:
        """Obtiene el mnemonic phrase"""
        return self.mnemonic_phrase
    
    def get_mnemonic_words(self) -> List[str]:
        """Obtiene las palabras del mnemonic como lista"""
        return self.mnemonic_phrase.split()
    
    @staticmethod
    def from_mnemonic(mnemonic_phrase: str) -> 'HDWallet':
        """Crea un HDWallet desde un mnemonic existente"""
        return HDWallet(mnemonic_phrase=mnemonic_phrase)
    
    @staticmethod
    def generate_new() -> 'HDWallet':
        """Genera un nuevo HDWallet"""
        return HDWallet()


class KeyManager:
    """Gestor de claves para el wallet"""
    
    def __init__(self):
        self.hd_wallet: Optional[HDWallet] = None
        self.imported_keys: dict = {}  # address -> private_key
        self.address_index = 0
    
    def create_new_wallet(self) -> str:
        """
        Crea un nuevo wallet HD
        
        Returns:
            Mnemonic phrase (IMPORTANTE: debe guardarse)
        """
        self.hd_wallet = HDWallet.generate_new()
        self.address_index = 0
        return self.hd_wallet.get_mnemonic()
    
    def restore_wallet(self, mnemonic_phrase: str):
        """Restaura un wallet desde mnemonic"""
        self.hd_wallet = HDWallet.from_mnemonic(mnemonic_phrase)
        self.address_index = 0
    
    def get_new_address(self) -> str:
        """Genera una nueva dirección"""
        if not self.hd_wallet:
            raise ValueError("Wallet no inicializado")
        
        address = self.hd_wallet.get_address(index=self.address_index)
        self.address_index += 1
        return address
    
    def get_addresses(self, count: int = 10) -> List[str]:
        """Obtiene múltiples direcciones"""
        if not self.hd_wallet:
            raise ValueError("Wallet no inicializado")
        
        addresses = []
        for i in range(count):
            address = self.hd_wallet.get_address(index=i)
            addresses.append(address)
        
        return addresses
    
    def get_private_key_for_address(self, address: str) -> Optional[bytes]:
        """Obtiene la clave privada de una dirección"""
        # Buscar en claves importadas
        if address in self.imported_keys:
            return self.imported_keys[address]
        
        # Buscar en wallet HD
        if self.hd_wallet:
            # Buscar en las primeras N direcciones
            for i in range(max(100, self.address_index + 10)):
                key = self.hd_wallet.derive_address_key(index=i)
                if key.get_address() == address:
                    return key.private_key
        
        return None
    
    def import_private_key(self, private_key: bytes) -> str:
        """
        Importa una clave privada
        
        Returns:
            Dirección correspondiente
        """
        address = TIFICrypto.private_key_to_address(private_key)
        self.imported_keys[address] = private_key
        return address
    
    def import_wif(self, wif: str) -> str:
        """
        Importa una clave desde formato WIF
        
        Returns:
            Dirección correspondiente
        """
        private_key, _ = TIFICrypto.wif_to_private_key(wif)
        return self.import_private_key(private_key)
    
    def export_private_key(self, address: str, format: str = 'hex') -> Optional[str]:
        """
        Exporta una clave privada
        
        Args:
            address: Dirección a exportar
            format: 'hex' o 'wif'
        
        Returns:
            Clave privada en el formato solicitado
        """
        private_key = self.get_private_key_for_address(address)
        
        if not private_key:
            return None
        
        if format == 'hex':
            return TIFICrypto.private_key_to_hex(private_key)
        elif format == 'wif':
            return TIFICrypto.private_key_to_wif(private_key)
        else:
            return None
    
    def has_wallet(self) -> bool:
        """Verifica si hay un wallet inicializado"""
        return self.hd_wallet is not None
    
    def get_wallet_info(self) -> dict:
        """Obtiene información del wallet"""
        if not self.hd_wallet:
            return {"initialized": False}
        
        return {
            "initialized": True,
            "address_count": self.address_index,
            "imported_keys": len(self.imported_keys),
            "mnemonic_words": len(self.hd_wallet.get_mnemonic_words())
        }
