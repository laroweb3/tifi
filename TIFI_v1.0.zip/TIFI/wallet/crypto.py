"""
TIFI Blockchain - Cryptography Module
Funciones criptográficas para firmas y verificación
"""

import hashlib
import ecdsa
import base58
from typing import Tuple, Optional


class TIFICrypto:
    """Utilidades criptográficas para TIFI"""
    
    # Prefijo para direcciones TIFI (T en Base58)
    ADDRESS_PREFIX = b'\x41'  # 'T' en Base58
    
    @staticmethod
    def generate_keypair() -> Tuple[bytes, bytes]:
        """
        Genera un par de claves ECDSA
        
        Returns:
            (private_key, public_key): Tupla con claves en bytes
        """
        # Generar clave privada
        signing_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
        private_key = signing_key.to_string()
        
        # Obtener clave pública
        verifying_key = signing_key.get_verifying_key()
        public_key = verifying_key.to_string()
        
        return private_key, public_key
    
    @staticmethod
    def private_key_to_public_key(private_key: bytes) -> bytes:
        """Deriva la clave pública desde la clave privada"""
        signing_key = ecdsa.SigningKey.from_string(private_key, curve=ecdsa.SECP256k1)
        verifying_key = signing_key.get_verifying_key()
        return verifying_key.to_string()
    
    @staticmethod
    def public_key_to_address(public_key: bytes) -> str:
        """
        Convierte una clave pública a una dirección TIFI
        
        Args:
            public_key: Clave pública en bytes
        
        Returns:
            Dirección TIFI en formato Base58Check
        """
        # SHA-256 de la clave pública
        sha256_hash = hashlib.sha256(public_key).digest()
        
        # RIPEMD-160 del hash SHA-256
        ripemd160 = hashlib.new('ripemd160')
        ripemd160.update(sha256_hash)
        hashed_public_key = ripemd160.digest()
        
        # Añadir prefijo de versión
        versioned_payload = TIFICrypto.ADDRESS_PREFIX + hashed_public_key
        
        # Calcular checksum (primeros 4 bytes de doble SHA-256)
        checksum = hashlib.sha256(hashlib.sha256(versioned_payload).digest()).digest()[:4]
        
        # Concatenar y codificar en Base58
        address_bytes = versioned_payload + checksum
        address = base58.b58encode(address_bytes).decode('ascii')
        
        return address
    
    @staticmethod
    def private_key_to_address(private_key: bytes) -> str:
        """Convierte una clave privada a una dirección TIFI"""
        public_key = TIFICrypto.private_key_to_public_key(private_key)
        return TIFICrypto.public_key_to_address(public_key)
    
    @staticmethod
    def validate_address(address: str) -> bool:
        """
        Valida una dirección TIFI
        
        Args:
            address: Dirección en formato Base58Check
        
        Returns:
            True si la dirección es válida
        """
        try:
            # Decodificar Base58
            decoded = base58.b58decode(address)
            
            # Verificar longitud (1 byte prefijo + 20 bytes hash + 4 bytes checksum)
            if len(decoded) != 25:
                return False
            
            # Separar componentes
            versioned_payload = decoded[:-4]
            checksum = decoded[-4:]
            
            # Verificar prefijo
            if versioned_payload[0:1] != TIFICrypto.ADDRESS_PREFIX:
                return False
            
            # Verificar checksum
            calculated_checksum = hashlib.sha256(hashlib.sha256(versioned_payload).digest()).digest()[:4]
            
            return checksum == calculated_checksum
        
        except Exception:
            return False
    
    @staticmethod
    def sign_message(private_key: bytes, message: bytes) -> bytes:
        """
        Firma un mensaje con una clave privada
        
        Args:
            private_key: Clave privada en bytes
            message: Mensaje a firmar en bytes
        
        Returns:
            Firma en bytes
        """
        signing_key = ecdsa.SigningKey.from_string(private_key, curve=ecdsa.SECP256k1)
        signature = signing_key.sign(message, hashfunc=hashlib.sha256)
        return signature
    
    @staticmethod
    def verify_signature(public_key: bytes, message: bytes, signature: bytes) -> bool:
        """
        Verifica una firma
        
        Args:
            public_key: Clave pública en bytes
            message: Mensaje original en bytes
            signature: Firma a verificar en bytes
        
        Returns:
            True si la firma es válida
        """
        try:
            verifying_key = ecdsa.VerifyingKey.from_string(public_key, curve=ecdsa.SECP256k1)
            verifying_key.verify(signature, message, hashfunc=hashlib.sha256)
            return True
        except ecdsa.BadSignatureError:
            return False
        except Exception:
            return False
    
    @staticmethod
    def hash256(data: bytes) -> bytes:
        """Doble SHA-256"""
        return hashlib.sha256(hashlib.sha256(data).digest()).digest()
    
    @staticmethod
    def hash160(data: bytes) -> bytes:
        """SHA-256 seguido de RIPEMD-160"""
        sha256_hash = hashlib.sha256(data).digest()
        ripemd160 = hashlib.new('ripemd160')
        ripemd160.update(sha256_hash)
        return ripemd160.digest()
    
    @staticmethod
    def private_key_to_wif(private_key: bytes, compressed: bool = True) -> str:
        """
        Convierte una clave privada a formato WIF (Wallet Import Format)
        
        Args:
            private_key: Clave privada en bytes
            compressed: Si la clave pública es comprimida
        
        Returns:
            Clave privada en formato WIF
        """
        # Añadir prefijo (0x80 para mainnet)
        extended_key = b'\x80' + private_key
        
        # Añadir sufijo si es comprimida
        if compressed:
            extended_key += b'\x01'
        
        # Calcular checksum
        checksum = TIFICrypto.hash256(extended_key)[:4]
        
        # Codificar en Base58
        wif = base58.b58encode(extended_key + checksum).decode('ascii')
        
        return wif
    
    @staticmethod
    def wif_to_private_key(wif: str) -> Tuple[bytes, bool]:
        """
        Convierte una clave WIF a bytes
        
        Args:
            wif: Clave en formato WIF
        
        Returns:
            (private_key, compressed): Tupla con clave y si es comprimida
        """
        # Decodificar Base58
        decoded = base58.b58decode(wif)
        
        # Verificar checksum
        extended_key = decoded[:-4]
        checksum = decoded[-4:]
        calculated_checksum = TIFICrypto.hash256(extended_key)[:4]
        
        if checksum != calculated_checksum:
            raise ValueError("Checksum inválido")
        
        # Remover prefijo
        private_key_data = extended_key[1:]
        
        # Verificar si es comprimida
        compressed = False
        if len(private_key_data) == 33 and private_key_data[-1:] == b'\x01':
            compressed = True
            private_key_data = private_key_data[:-1]
        
        return private_key_data, compressed
    
    @staticmethod
    def private_key_to_hex(private_key: bytes) -> str:
        """Convierte clave privada a hexadecimal"""
        return private_key.hex()
    
    @staticmethod
    def hex_to_private_key(hex_string: str) -> bytes:
        """Convierte hexadecimal a clave privada"""
        return bytes.fromhex(hex_string)
    
    @staticmethod
    def public_key_to_hex(public_key: bytes) -> str:
        """Convierte clave pública a hexadecimal"""
        return public_key.hex()
    
    @staticmethod
    def hex_to_public_key(hex_string: str) -> bytes:
        """Convierte hexadecimal a clave pública"""
        return bytes.fromhex(hex_string)


# Funciones de conveniencia
def generate_address() -> Tuple[str, bytes, bytes]:
    """
    Genera una nueva dirección TIFI con sus claves
    
    Returns:
        (address, private_key, public_key): Tupla con dirección y claves
    """
    private_key, public_key = TIFICrypto.generate_keypair()
    address = TIFICrypto.public_key_to_address(public_key)
    return address, private_key, public_key


def sign_transaction_data(private_key: bytes, tx_data: str) -> str:
    """
    Firma datos de una transacción
    
    Args:
        private_key: Clave privada en bytes
        tx_data: Datos de la transacción en string
    
    Returns:
        Firma en hexadecimal
    """
    message = tx_data.encode('utf-8')
    signature = TIFICrypto.sign_message(private_key, message)
    return signature.hex()


def verify_transaction_signature(public_key: bytes, tx_data: str, signature_hex: str) -> bool:
    """
    Verifica la firma de una transacción
    
    Args:
        public_key: Clave pública en bytes
        tx_data: Datos de la transacción en string
        signature_hex: Firma en hexadecimal
    
    Returns:
        True si la firma es válida
    """
    message = tx_data.encode('utf-8')
    signature = bytes.fromhex(signature_hex)
    return TIFICrypto.verify_signature(public_key, message, signature)
