#!/bin/bash
###############################################################################
# TIFI - Instalador para Linux
# Instala el nodo TIFI y lo configura como servicio systemd
###############################################################################

set -e

echo "============================================================"
echo "  TIFI - Time Fidelity Blockchain"
echo "  Instalador para Linux"
echo "============================================================"
echo ""

# Verificar que se ejecuta como root o con sudo
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Este script debe ejecutarse como root o con sudo"
    exit 1
fi

# Detectar usuario real (no root)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(eval echo ~$REAL_USER)

echo "[1/8] Verificando dependencias..."

# Verificar Python 3
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 no está instalado"
    echo "   Instala Python 3.8 o superior y vuelve a ejecutar este script"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "   ✓ Python $PYTHON_VERSION encontrado"

# Verificar pip
if ! command -v pip3 &> /dev/null; then
    echo "   Instalando pip..."
    apt-get update -qq
    apt-get install -y python3-pip
fi

echo "[2/8] Instalando dependencias de Python..."
pip3 install -q ecdsa base58 mnemonic

echo "[3/8] Creando directorios..."
INSTALL_DIR="/opt/tifi"
mkdir -p "$INSTALL_DIR"
mkdir -p "$REAL_HOME/.tifi"
chown -R $REAL_USER:$REAL_USER "$REAL_HOME/.tifi"

echo "[4/8] Copiando archivos..."
# Copiar todos los archivos del proyecto
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/tifi_node.py"
chmod +x "$INSTALL_DIR/tifi_cli.py"

echo "[5/8] Creando enlaces simbólicos..."
ln -sf "$INSTALL_DIR/tifi_node.py" /usr/local/bin/tifi-node
ln -sf "$INSTALL_DIR/tifi_cli.py" /usr/local/bin/tifi-cli

echo "[6/8] Creando servicio systemd..."
cat > /etc/systemd/system/tifi.service << EOF
[Unit]
Description=TIFI Blockchain Node
After=network.target

[Service]
Type=simple
User=$REAL_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/tifi_node.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo "[7/8] Habilitando servicio..."
systemctl daemon-reload
systemctl enable tifi.service

echo "[8/8] Creando script de desinstalación..."
cat > /usr/local/bin/tifi-uninstall << 'EOF'
#!/bin/bash
echo "Desinstalando TIFI..."
systemctl stop tifi.service 2>/dev/null || true
systemctl disable tifi.service 2>/dev/null || true
rm -f /etc/systemd/system/tifi.service
rm -f /usr/local/bin/tifi-node
rm -f /usr/local/bin/tifi-cli
rm -f /usr/local/bin/tifi-uninstall
rm -rf /opt/tifi
systemctl daemon-reload
echo "✓ TIFI desinstalado"
echo "Nota: Los datos del wallet en ~/.tifi no fueron eliminados"
EOF
chmod +x /usr/local/bin/tifi-uninstall

echo ""
echo "============================================================"
echo "  ✓ INSTALACIÓN COMPLETADA"
echo "============================================================"
echo ""
echo "Comandos disponibles:"
echo "  tifi-node          - Ejecutar nodo manualmente"
echo "  tifi-cli           - Interfaz de línea de comandos"
echo "  tifi-uninstall     - Desinstalar TIFI"
echo ""
echo "Servicio systemd:"
echo "  sudo systemctl start tifi    - Iniciar nodo"
echo "  sudo systemctl stop tifi     - Detener nodo"
echo "  sudo systemctl status tifi   - Ver estado"
echo "  sudo journalctl -u tifi -f   - Ver logs"
echo ""
echo "Directorio de datos: $REAL_HOME/.tifi"
echo ""
echo "Para iniciar el nodo ahora:"
echo "  sudo systemctl start tifi"
echo ""
echo "============================================================"
