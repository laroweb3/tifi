"""
TIFI Blockchain - Network Node
Nodo principal que maneja la red P2P
"""

import asyncio
import time
from typing import Optional, List
from peer import PeerManager, PeerConnection
from discovery import PeerDiscovery, DNSSeeder
from protocol import Message, MessageFactory, ProtocolHandler


class NetworkNode:
    """Nodo de red P2P"""
    
    DEFAULT_PORT = 8333
    
    def __init__(self, blockchain, port: int = DEFAULT_PORT):
        self.blockchain = blockchain
        self.port = port
        self.peer_manager = PeerManager()
        self.discovery = PeerDiscovery(port, self.peer_manager)
        self.protocol_handler = ProtocolHandler(self)
        
        self.server: Optional[asyncio.Server] = None
        self.running = False
        
        # Estadísticas
        self.start_time = 0.0
        self.messages_sent = 0
        self.messages_received = 0
        self.bytes_sent = 0
        self.bytes_received = 0
    
    async def start(self):
        """Inicia el nodo de red"""
        print(f"Iniciando nodo TIFI en puerto {self.port}...")
        
        self.running = True
        self.start_time = time.time()
        
        # Iniciar servidor TCP
        self.server = await asyncio.start_server(
            self._handle_client,
            '0.0.0.0',
            self.port
        )
        
        print(f"✓ Servidor TCP escuchando en puerto {self.port}")
        
        # Iniciar descubrimiento de peers
        await self.discovery.start()
        
        # Conectar a peers iniciales
        asyncio.create_task(self._connect_to_initial_peers())
        
        # Iniciar tareas de mantenimiento
        asyncio.create_task(self._maintenance_loop())
        
        print(f"✓ Nodo TIFI iniciado correctamente")
    
    async def stop(self):
        """Detiene el nodo"""
        print("Deteniendo nodo...")
        
        self.running = False
        
        # Detener descubrimiento
        await self.discovery.stop()
        
        # Desconectar todos los peers
        for peer_addr in list(self.peer_manager.connections.keys()):
            await self.peer_manager.disconnect_from_peer(peer_addr)
        
        # Cerrar servidor
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        print("✓ Nodo detenido")
    
    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Maneja una conexión entrante"""
        peer_addr = writer.get_extra_info('peername')
        peer_address = peer_addr[0]
        peer_port = peer_addr[1]
        
        print(f"Nueva conexión entrante de {peer_address}:{peer_port}")
        
        # Añadir peer
        self.peer_manager.add_peer(peer_address, peer_port)
        
        # Crear conexión
        peer_info = self.peer_manager.get_peer(f"{peer_address}:{peer_port}")
        if peer_info:
            peer_info.connected = True
            connection = PeerConnection(peer_info, reader, writer)
            self.peer_manager.connections[f"{peer_address}:{peer_port}"] = connection
            
            # Enviar VERSION
            version_msg = MessageFactory.create_version(
                version=1,
                services=1,
                timestamp=time.time(),
                addr_recv=f"{peer_address}:{peer_port}",
                addr_from=f"0.0.0.0:{self.port}",
                nonce=int(time.time()),
                user_agent="TIFI/1.0.0",
                start_height=self.blockchain.get_height()
            )
            await connection.send_message(version_msg)
            
            # Manejar mensajes
            await self._handle_peer_messages(connection)
    
    async def _handle_peer_messages(self, connection: PeerConnection):
        """Maneja mensajes de un peer"""
        peer_addr = connection.peer_info.get_address_string()
        
        while connection.connected and self.running:
            try:
                message = await connection.receive_message()
                
                if message:
                    self.messages_received += 1
                    await self.protocol_handler.handle_message(message, peer_addr)
                else:
                    # Conexión cerrada
                    break
            
            except Exception as e:
                print(f"Error manejando mensajes de {peer_addr}: {e}")
                break
        
        # Desconectar
        await self.peer_manager.disconnect_from_peer(peer_addr)
    
    async def _connect_to_initial_peers(self):
        """Conecta a peers iniciales"""
        # Esperar un poco para que el descubrimiento encuentre peers
        await asyncio.sleep(5)
        
        # Obtener DNS seeds
        seed_nodes = await DNSSeeder.get_seed_nodes()
        
        for address, port in seed_nodes:
            self.peer_manager.add_peer(address, port)
        
        # Conectar a algunos peers
        peers = self.peer_manager.get_all_peers()
        
        for peer in peers[:8]:  # Conectar a máximo 8 peers iniciales
            if not peer.connected:
                connection = await self.peer_manager.connect_to_peer(peer.address, peer.port)
                
                if connection:
                    # Enviar VERSION
                    version_msg = MessageFactory.create_version(
                        version=1,
                        services=1,
                        timestamp=time.time(),
                        addr_recv=f"{peer.address}:{peer.port}",
                        addr_from=f"0.0.0.0:{self.port}",
                        nonce=int(time.time()),
                        user_agent="TIFI/1.0.0",
                        start_height=self.blockchain.get_height()
                    )
                    await connection.send_message(version_msg)
                    
                    # Iniciar manejo de mensajes
                    asyncio.create_task(self._handle_peer_messages(connection))
    
    async def _maintenance_loop(self):
        """Loop de mantenimiento del nodo"""
        while self.running:
            try:
                # Ping a todos los peers cada minuto
                await self.peer_manager.ping_all_peers()
                
                # Limpiar peers inactivos
                self.peer_manager._cleanup_inactive_peers()
                
                # Intentar conectar a más peers si es necesario
                total, connected = self.peer_manager.get_peer_count()
                
                if connected < 3:
                    # Solicitar más peers
                    await self.discovery.request_peers_from_network()
                    
                    # Intentar conectar a peers conocidos
                    peers = self.peer_manager.get_all_peers()
                    for peer in peers[:5]:
                        if not peer.connected:
                            await self.peer_manager.connect_to_peer(peer.address, peer.port)
                
                # Mostrar estadísticas
                stats = self.get_stats()
                print(f"[Nodo] Altura: {stats['blockchain_height']}, Peers: {stats['connected_peers']}/{stats['total_peers']}, Mempool: {stats['mempool_size']}")
            
            except Exception as e:
                print(f"Error en maintenance loop: {e}")
            
            await asyncio.sleep(60)
    
    async def send_message(self, peer_addr: str, message: Message):
        """Envía un mensaje a un peer específico"""
        if peer_addr in self.peer_manager.connections:
            connection = self.peer_manager.connections[peer_addr]
            await connection.send_message(message)
            self.messages_sent += 1
    
    async def broadcast_message(self, message: Message, exclude: Optional[List[str]] = None):
        """Broadcast de un mensaje a todos los peers"""
        await self.peer_manager.broadcast_message(message, exclude)
        self.messages_sent += len(self.peer_manager.connections)
    
    async def broadcast_transaction(self, tx):
        """Broadcast de una transacción"""
        tx_msg = MessageFactory.create_tx(tx.to_dict())
        await self.broadcast_message(tx_msg)
    
    async def broadcast_block(self, block):
        """Broadcast de un bloque"""
        block_msg = MessageFactory.create_block(block.to_dict())
        await self.broadcast_message(block_msg)
    
    async def sync_blockchain(self):
        """Sincroniza la blockchain con la red"""
        print("Iniciando sincronización de blockchain...")
        
        # Obtener altura de peers
        max_height = self.blockchain.get_height()
        
        for peer_info in self.peer_manager.get_connected_peers():
            if peer_info.height > max_height:
                max_height = peer_info.height
        
        if max_height <= self.blockchain.get_height():
            print("✓ Blockchain ya está sincronizada")
            return
        
        # Solicitar bloques faltantes
        current_height = self.blockchain.get_height()
        
        while current_height < max_height:
            # Solicitar bloques en lotes de 500
            end_height = min(current_height + 500, max_height)
            
            getblocks_msg = MessageFactory.create_getblocks(current_height + 1, end_height)
            
            # Enviar a un peer con altura suficiente
            for peer_addr, connection in self.peer_manager.connections.items():
                if connection.peer_info.height >= end_height:
                    await connection.send_message(getblocks_msg)
                    break
            
            # Esperar a que se procesen los bloques
            await asyncio.sleep(5)
            
            # Verificar progreso
            new_height = self.blockchain.get_height()
            if new_height == current_height:
                # No hubo progreso, reintentar
                print(f"Sin progreso en sincronización, reintentando...")
                await asyncio.sleep(10)
            else:
                current_height = new_height
                print(f"Sincronización: {current_height}/{max_height} bloques")
        
        print("✓ Blockchain sincronizada")
    
    def get_peer_list(self) -> List[str]:
        """Obtiene lista de peers para compartir"""
        peers = []
        for peer_info in self.peer_manager.get_all_peers():
            if peer_info.is_alive():
                peers.append(f"{peer_info.address}:{peer_info.port}")
        return peers
    
    async def add_peer(self, peer_addr: str):
        """Añade un peer desde una dirección string"""
        try:
            address, port = peer_addr.split(':')
            port = int(port)
            self.peer_manager.add_peer(address, port)
        except:
            pass
    
    def get_stats(self) -> dict:
        """Obtiene estadísticas del nodo"""
        total_peers, connected_peers = self.peer_manager.get_peer_count()
        uptime = time.time() - self.start_time if self.start_time > 0 else 0
        
        return {
            "uptime": uptime,
            "blockchain_height": self.blockchain.get_height(),
            "total_peers": total_peers,
            "connected_peers": connected_peers,
            "mempool_size": self.blockchain.transaction_pool.size(),
            "messages_sent": self.messages_sent,
            "messages_received": self.messages_received,
            "bytes_sent": self.bytes_sent,
            "bytes_received": self.bytes_received
        }
    
    def __repr__(self) -> str:
        total, connected = self.peer_manager.get_peer_count()
        return f"NetworkNode(port={self.port}, peers={connected}/{total}, height={self.blockchain.get_height()})"
