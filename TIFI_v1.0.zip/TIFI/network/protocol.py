"""
TIFI Blockchain - Network Protocol
Define los mensajes y protocolo de comunicación P2P
"""

import json
import struct
from enum import Enum
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict


class MessageType(Enum):
    """Tipos de mensajes en el protocolo TIFI"""
    VERSION = 1
    VERACK = 2
    PING = 3
    PONG = 4
    GETPEERS = 5
    PEERS = 6
    GETBLOCKS = 7
    BLOCKS = 8
    GETBLOCK = 9
    BLOCK = 10
    TX = 11
    INV = 12
    GETDATA = 13
    NOTFOUND = 14
    MEMPOOL = 15


class InventoryType(Enum):
    """Tipos de inventario"""
    TX = 1
    BLOCK = 2


@dataclass
class InventoryVector:
    """Vector de inventario"""
    inv_type: int  # InventoryType
    hash: str
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class Message:
    """Mensaje base del protocolo TIFI"""
    
    MAGIC_BYTES = b'TIFI'
    VERSION = 1
    MAX_PAYLOAD_SIZE = 32 * 1024 * 1024  # 32MB
    
    def __init__(self, msg_type: MessageType, payload: Dict):
        self.msg_type = msg_type
        self.payload = payload
        self.version = self.VERSION
    
    def serialize(self) -> bytes:
        """Serializa el mensaje a bytes"""
        # Convertir payload a JSON
        payload_json = json.dumps(self.payload)
        payload_bytes = payload_json.encode('utf-8')
        
        # Calcular checksum
        checksum = self._calculate_checksum(payload_bytes)
        
        # Estructura del mensaje:
        # - Magic bytes (4 bytes)
        # - Version (1 byte)
        # - Message type (1 byte)
        # - Payload length (4 bytes)
        # - Checksum (4 bytes)
        # - Payload (variable)
        
        header = struct.pack(
            '!4sBBI4s',
            self.MAGIC_BYTES,
            self.version,
            self.msg_type.value,
            len(payload_bytes),
            checksum
        )
        
        return header + payload_bytes
    
    @classmethod
    def deserialize(cls, data: bytes) -> Optional['Message']:
        """Deserializa bytes a un mensaje"""
        if len(data) < 14:  # Tamaño mínimo del header
            return None
        
        # Parsear header
        try:
            magic, version, msg_type_val, payload_len, checksum = struct.unpack(
                '!4sBBI4s',
                data[:14]
            )
        except struct.error:
            return None
        
        # Verificar magic bytes
        if magic != cls.MAGIC_BYTES:
            return None
        
        # Verificar longitud
        if len(data) < 14 + payload_len:
            return None
        
        # Extraer payload
        payload_bytes = data[14:14 + payload_len]
        
        # Verificar checksum
        if cls._calculate_checksum(payload_bytes) != checksum:
            return None
        
        # Parsear payload
        try:
            payload = json.loads(payload_bytes.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None
        
        # Crear mensaje
        try:
            msg_type = MessageType(msg_type_val)
        except ValueError:
            return None
        
        return cls(msg_type, payload)
    
    @staticmethod
    def _calculate_checksum(data: bytes) -> bytes:
        """Calcula checksum de los datos"""
        import hashlib
        hash1 = hashlib.sha256(data).digest()
        hash2 = hashlib.sha256(hash1).digest()
        return hash2[:4]
    
    def to_dict(self) -> Dict:
        """Convierte el mensaje a diccionario"""
        return {
            "type": self.msg_type.name,
            "payload": self.payload
        }
    
    def __repr__(self) -> str:
        return f"Message(type={self.msg_type.name}, payload_size={len(str(self.payload))})"


class MessageFactory:
    """Factory para crear mensajes del protocolo"""
    
    @staticmethod
    def create_version(
        version: int,
        services: int,
        timestamp: float,
        addr_recv: str,
        addr_from: str,
        nonce: int,
        user_agent: str,
        start_height: int
    ) -> Message:
        """Crea un mensaje VERSION"""
        payload = {
            "version": version,
            "services": services,
            "timestamp": timestamp,
            "addr_recv": addr_recv,
            "addr_from": addr_from,
            "nonce": nonce,
            "user_agent": user_agent,
            "start_height": start_height
        }
        return Message(MessageType.VERSION, payload)
    
    @staticmethod
    def create_verack() -> Message:
        """Crea un mensaje VERACK"""
        return Message(MessageType.VERACK, {})
    
    @staticmethod
    def create_ping(nonce: int) -> Message:
        """Crea un mensaje PING"""
        return Message(MessageType.PING, {"nonce": nonce})
    
    @staticmethod
    def create_pong(nonce: int) -> Message:
        """Crea un mensaje PONG"""
        return Message(MessageType.PONG, {"nonce": nonce})
    
    @staticmethod
    def create_getpeers() -> Message:
        """Crea un mensaje GETPEERS"""
        return Message(MessageType.GETPEERS, {})
    
    @staticmethod
    def create_peers(peers: list) -> Message:
        """Crea un mensaje PEERS"""
        return Message(MessageType.PEERS, {"peers": peers})
    
    @staticmethod
    def create_getblocks(start_height: int, end_height: int) -> Message:
        """Crea un mensaje GETBLOCKS"""
        payload = {
            "start_height": start_height,
            "end_height": end_height
        }
        return Message(MessageType.GETBLOCKS, payload)
    
    @staticmethod
    def create_blocks(blocks: list) -> Message:
        """Crea un mensaje BLOCKS"""
        return Message(MessageType.BLOCKS, {"blocks": blocks})
    
    @staticmethod
    def create_getblock(block_hash: str) -> Message:
        """Crea un mensaje GETBLOCK"""
        return Message(MessageType.GETBLOCK, {"block_hash": block_hash})
    
    @staticmethod
    def create_block(block_data: Dict) -> Message:
        """Crea un mensaje BLOCK"""
        return Message(MessageType.BLOCK, {"block": block_data})
    
    @staticmethod
    def create_tx(tx_data: Dict) -> Message:
        """Crea un mensaje TX"""
        return Message(MessageType.TX, {"transaction": tx_data})
    
    @staticmethod
    def create_inv(inventory: list) -> Message:
        """Crea un mensaje INV"""
        return Message(MessageType.INV, {"inventory": inventory})
    
    @staticmethod
    def create_getdata(inventory: list) -> Message:
        """Crea un mensaje GETDATA"""
        return Message(MessageType.GETDATA, {"inventory": inventory})
    
    @staticmethod
    def create_notfound(inventory: list) -> Message:
        """Crea un mensaje NOTFOUND"""
        return Message(MessageType.NOTFOUND, {"inventory": inventory})
    
    @staticmethod
    def create_mempool() -> Message:
        """Crea un mensaje MEMPOOL"""
        return Message(MessageType.MEMPOOL, {})


class ProtocolHandler:
    """Manejador del protocolo de red"""
    
    PROTOCOL_VERSION = 1
    USER_AGENT = "TIFI/1.0.0"
    SERVICES = 1  # NODE_NETWORK
    
    def __init__(self, node):
        self.node = node
    
    async def handle_message(self, message: Message, peer_address: str):
        """Maneja un mensaje recibido"""
        handler_map = {
            MessageType.VERSION: self._handle_version,
            MessageType.VERACK: self._handle_verack,
            MessageType.PING: self._handle_ping,
            MessageType.PONG: self._handle_pong,
            MessageType.GETPEERS: self._handle_getpeers,
            MessageType.PEERS: self._handle_peers,
            MessageType.GETBLOCKS: self._handle_getblocks,
            MessageType.BLOCKS: self._handle_blocks,
            MessageType.GETBLOCK: self._handle_getblock,
            MessageType.BLOCK: self._handle_block,
            MessageType.TX: self._handle_tx,
            MessageType.INV: self._handle_inv,
            MessageType.GETDATA: self._handle_getdata,
            MessageType.NOTFOUND: self._handle_notfound,
            MessageType.MEMPOOL: self._handle_mempool
        }
        
        handler = handler_map.get(message.msg_type)
        if handler:
            await handler(message, peer_address)
        else:
            print(f"Mensaje desconocido: {message.msg_type}")
    
    async def _handle_version(self, message: Message, peer_address: str):
        """Maneja mensaje VERSION"""
        payload = message.payload
        print(f"VERSION recibido de {peer_address}: {payload.get('user_agent')}")
        
        # Responder con VERACK
        verack = MessageFactory.create_verack()
        await self.node.send_message(peer_address, verack)
    
    async def _handle_verack(self, message: Message, peer_address: str):
        """Maneja mensaje VERACK"""
        print(f"VERACK recibido de {peer_address}")
        # Conexión establecida
    
    async def _handle_ping(self, message: Message, peer_address: str):
        """Maneja mensaje PING"""
        nonce = message.payload.get("nonce", 0)
        pong = MessageFactory.create_pong(nonce)
        await self.node.send_message(peer_address, pong)
    
    async def _handle_pong(self, message: Message, peer_address: str):
        """Maneja mensaje PONG"""
        # Actualizar latencia del peer
        pass
    
    async def _handle_getpeers(self, message: Message, peer_address: str):
        """Maneja mensaje GETPEERS"""
        peers = self.node.get_peer_list()
        peers_msg = MessageFactory.create_peers(peers)
        await self.node.send_message(peer_address, peers_msg)
    
    async def _handle_peers(self, message: Message, peer_address: str):
        """Maneja mensaje PEERS"""
        peers = message.payload.get("peers", [])
        for peer in peers:
            await self.node.add_peer(peer)
    
    async def _handle_getblocks(self, message: Message, peer_address: str):
        """Maneja mensaje GETBLOCKS"""
        start_height = message.payload.get("start_height", 0)
        end_height = message.payload.get("end_height", -1)
        
        blocks = []
        for height in range(start_height, min(end_height + 1, self.node.blockchain.get_height() + 1)):
            block = self.node.blockchain.get_block_by_height(height)
            if block:
                blocks.append(block.to_dict())
        
        blocks_msg = MessageFactory.create_blocks(blocks)
        await self.node.send_message(peer_address, blocks_msg)
    
    async def _handle_blocks(self, message: Message, peer_address: str):
        """Maneja mensaje BLOCKS"""
        from block import Block
        
        blocks_data = message.payload.get("blocks", [])
        for block_data in blocks_data:
            block = Block.from_dict(block_data)
            self.node.blockchain.add_block(block)
    
    async def _handle_getblock(self, message: Message, peer_address: str):
        """Maneja mensaje GETBLOCK"""
        block_hash = message.payload.get("block_hash")
        block = self.node.blockchain.get_block_by_hash(block_hash)
        
        if block:
            block_msg = MessageFactory.create_block(block.to_dict())
            await self.node.send_message(peer_address, block_msg)
    
    async def _handle_block(self, message: Message, peer_address: str):
        """Maneja mensaje BLOCK"""
        from block import Block
        
        block_data = message.payload.get("block")
        if block_data:
            block = Block.from_dict(block_data)
            self.node.blockchain.add_block(block)
    
    async def _handle_tx(self, message: Message, peer_address: str):
        """Maneja mensaje TX"""
        from transaction import Transaction
        
        tx_data = message.payload.get("transaction")
        if tx_data:
            tx = Transaction.from_dict(tx_data)
            self.node.blockchain.add_transaction(tx)
    
    async def _handle_inv(self, message: Message, peer_address: str):
        """Maneja mensaje INV"""
        inventory = message.payload.get("inventory", [])
        # Solicitar datos que no tenemos
        # TODO: Implementar lógica de solicitud
    
    async def _handle_getdata(self, message: Message, peer_address: str):
        """Maneja mensaje GETDATA"""
        inventory = message.payload.get("inventory", [])
        # Enviar datos solicitados
        # TODO: Implementar lógica de envío
    
    async def _handle_notfound(self, message: Message, peer_address: str):
        """Maneja mensaje NOTFOUND"""
        # Datos no encontrados en el peer
        pass
    
    async def _handle_mempool(self, message: Message, peer_address: str):
        """Maneja mensaje MEMPOOL"""
        # Enviar transacciones del mempool
        txs = self.node.blockchain.transaction_pool.get_transactions()
        for tx in txs:
            tx_msg = MessageFactory.create_tx(tx.to_dict())
            await self.node.send_message(peer_address, tx_msg)
