# TIFI - Time Fidelity Blockchain

**TIFI** (Time Fidelity) es un protocolo blockchain autónomo, autoinstalable y autoreplicable diseñado para minería CPU y staking. El sistema opera como un organismo descentralizado que se expande naturalmente sin intervención humana, como una flor que crece donde se planta.

## 🌟 Características Principales

### Blockchain
- **Moneda**: Credits (CRED)
- **Supply máximo**: 21,000,000 CRED
- **Tiempo de bloque**: 60 segundos
- **Recompensa inicial**: 50 CRED
- **Halving**: Cada 210,000 bloques (~4 años)

### Consenso Híbrido PoW/PoS
- **70% PoW** (Proof of Work) - Minería CPU con SHA-256
- **30% PoS** (Proof of Stake) - Validación por stake
- **Ciclo**: 7 bloques PoW + 3 bloques PoS
- **Stake mínimo**: 100 CRED
- **Recompensa de stake**: 5% anual

### Red P2P Autodescubrible
- Descubrimiento automático de nodos en red local
- Bootstrap nodes para conexión inicial
- Protocolo de mensajes eficiente
- Sincronización automática de blockchain

### Wallet HD (Hierarchical Deterministic)
- Generación de claves BIP39/BIP44
- Seed phrase de 24 palabras
- Múltiples direcciones desde un solo seed
- Importación/exportación de claves privadas

### Minería CPU Optimizada
- Multi-threading automático
- Optimización para CPUs modernos
- Estadísticas en tiempo real
- Sin necesidad de hardware especializado

### Sistema de Staking
- Participación en consenso PoS
- Recompensas proporcionales al stake
- Maduración de 100 bloques
- Coin age limitado a 30 días

## 🚀 Instalación Rápida

### Linux

```bash
# Clonar o descargar el proyecto
cd TIFI

# Ejecutar instalador (requiere sudo)
sudo python3 install.py
```

El instalador:
- ✅ Instala todas las dependencias
- ✅ Configura el nodo como servicio systemd
- ✅ Crea comandos globales (`tifi-node`, `tifi-cli`)
- ✅ Genera wallet automáticamente

### Windows

```batch
# Descargar el proyecto
cd TIFI

# Ejecutar instalador (como Administrador)
python install.py
```

El instalador:
- ✅ Instala dependencias de Python
- ✅ Configura accesos directos
- ✅ Añade al PATH del sistema
- ✅ Genera wallet automáticamente

### Instalación Manual

```bash
# Instalar dependencias
pip3 install ecdsa base58 mnemonic

# Ejecutar nodo
python3 tifi_node.py
```

## 📖 Uso

### Iniciar el Nodo

**Linux (servicio):**
```bash
sudo systemctl start tifi
sudo systemctl status tifi
sudo journalctl -u tifi -f  # Ver logs
```

**Linux/Windows (manual):**
```bash
python3 tifi_node.py
```

### Comandos CLI

```bash
# Información del nodo
tifi-cli getinfo

# Balance del wallet
tifi-cli getbalance

# Nueva dirección
tifi-cli getnewaddress --label "Mi dirección"

# Listar direcciones
tifi-cli listaddresses

# Enviar CRED
tifi-cli send <dirección> <cantidad>

# Historial de transacciones
tifi-cli listtransactions

# Información de bloque
tifi-cli getblock <altura>

# Exportar clave privada
tifi-cli exportprivkey <dirección>

# Importar clave privada
tifi-cli importprivkey <clave_privada>

# Backup del wallet
tifi-cli backupwallet <ruta_destino>
```

## 🔧 Configuración

### Directorios

- **Linux**: `~/.tifi/`
- **Windows**: `%USERPROFILE%\.tifi\`

### Archivos

- `chain.json` - Blockchain completa
- `wallet.json` - Wallet y claves (⚠️ **MANTENER SEGURO**)
- `config.json` - Configuración del nodo

### Puertos

- **8333** - TCP para conexiones P2P
- **8334** - UDP para descubrimiento de nodos

## 💎 Minería

### Iniciar Minería

El nodo inicia automáticamente la minería cuando se ejecuta. Para control manual:

```python
# En el código del nodo
node.start_mining()  # Iniciar
node.stop_mining()   # Detener
```

### Estadísticas de Minería

```bash
# Ver estadísticas en tiempo real
tifi-cli getinfo
```

Muestra:
- Hashrate actual
- Bloques encontrados
- Dificultad de red
- Próximo tipo de bloque (PoW/PoS)

## 🏦 Staking

### Añadir Stake

```python
# Desde el nodo
node.staking_manager.add_stake(address, amount)
node.staking_manager.start_staking()
```

### Requisitos

- Mínimo: 100 CRED
- Maduración: 100 bloques (~100 minutos)
- Recompensa: 5% anual

### Auto-Stake

```python
# Hacer stake de todos los fondos disponibles
node.staking_manager.auto_stake_all(reserve=10.0)
```

## 🔐 Seguridad

### Seed Phrase

Al crear un nuevo wallet, se genera un **seed phrase de 24 palabras**:

```
⚠️  IMPORTANTE: GUARDA ESTAS 24 PALABRAS ⚠️

1. palabra1    2. palabra2    3. palabra3    4. palabra4
...
21. palabra21  22. palabra22  23. palabra23  24. palabra24

Estas palabras son necesarias para recuperar tu wallet.
¡GUÁRDALAS EN UN LUGAR SEGURO!
```

### Backup del Wallet

```bash
# Crear backup
tifi-cli backupwallet ~/tifi_backup.json

# Restaurar (copiar archivo a ~/.tifi/wallet.json)
cp ~/tifi_backup.json ~/.tifi/wallet.json
```

### Claves Privadas

```bash
# Exportar clave privada
tifi-cli exportprivkey <dirección> --format hex

# Importar clave privada
tifi-cli importprivkey <clave_privada> --label "Importada"
```

## 🌐 Red P2P

### Descubrimiento Automático

El nodo descubre peers automáticamente mediante:

1. **Broadcast UDP** en red local
2. **DNS Seeds** (bootstrap nodes)
3. **Peer Exchange** (PEX) con nodos conocidos

### Bootstrap Nodes

```
seed1.tifi.network:8333
seed2.tifi.network:8333
seed3.tifi.network:8333
```

### Conectividad

- **Máximo de peers**: 125
- **Outbound**: 8 conexiones salientes
- **Inbound**: 117 conexiones entrantes

## 📊 Arquitectura

```
TIFI/
├── core/                   # Núcleo blockchain
│   ├── blockchain.py      # Cadena y validación
│   ├── block.py           # Estructura de bloques
│   ├── transaction.py     # Transacciones
│   └── consensus.py       # PoW/PoS híbrido
├── network/               # Red P2P
│   ├── node.py           # Nodo principal
│   ├── peer.py           # Gestión de peers
│   ├── discovery.py      # Descubrimiento
│   └── protocol.py       # Protocolo de mensajes
├── wallet/               # Wallet y criptografía
│   ├── wallet.py        # Gestión de wallet
│   ├── keys.py          # Claves HD (BIP39/44)
│   └── crypto.py        # Funciones criptográficas
├── mining/              # Minería y staking
│   ├── miner.py        # Minero CPU
│   └── staking.py      # Sistema de staking
├── installer/          # Instaladores
│   ├── linux/         # Instalador Linux
│   └── windows/       # Instalador Windows
├── tifi_node.py       # Aplicación principal
├── tifi_cli.py        # CLI
└── install.py         # Instalador universal
```

## 🔬 Especificaciones Técnicas

### Algoritmo de Hash
- **PoW**: SHA-256 (doble hash)
- **Direcciones**: RIPEMD-160(SHA-256(pubkey))
- **Firmas**: ECDSA secp256k1

### Formato de Dirección
- **Prefijo**: 'T' (0x41 en Base58)
- **Formato**: Base58Check
- **Ejemplo**: `T1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9`

### Estructura de Bloque

```json
{
  "header": {
    "version": 1,
    "previous_hash": "...",
    "merkle_root": "...",
    "timestamp": 1234567890.0,
    "difficulty": 20,
    "nonce": 12345,
    "block_type": "pow",
    "stake_data": {}
  },
  "transactions": [...],
  "height": 100,
  "block_hash": "..."
}
```

### Estructura de Transacción

```json
{
  "tx_id": "...",
  "inputs": [
    {
      "tx_id": "...",
      "output_index": 0,
      "signature": "...",
      "public_key": "..."
    }
  ],
  "outputs": [
    {
      "address": "T1...",
      "amount": 10.5
    }
  ],
  "timestamp": 1234567890.0,
  "type": "regular"
}
```

## 🛠️ Desarrollo

### Requisitos

- Python 3.8+
- Dependencias: `ecdsa`, `base58`, `mnemonic`

### Ejecutar Tests

```bash
# TODO: Implementar tests
python3 -m pytest tests/
```

### Contribuir

TIFI es un proyecto de código abierto. Las contribuciones son bienvenidas:

1. Fork del repositorio
2. Crear rama de feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit de cambios (`git commit -am 'Añadir nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

## 📝 Roadmap

### Fase 1 - Núcleo (Completado) ✅
- [x] Blockchain básica
- [x] Transacciones
- [x] Consenso PoW/PoS
- [x] Wallet HD
- [x] Minería CPU
- [x] Staking

### Fase 2 - Red (Completado) ✅
- [x] Protocolo P2P
- [x] Descubrimiento de nodos
- [x] Sincronización

### Fase 3 - Instaladores (Completado) ✅
- [x] Instalador Linux
- [x] Instalador Windows
- [x] CLI

### Fase 4 - Mejoras (Futuro)
- [ ] Interfaz gráfica (Electron)
- [ ] Mining pools
- [ ] Smart contracts
- [ ] Lightning Network
- [ ] Mobile wallets
- [ ] Block explorer web

## ⚠️ Advertencias

- **Beta Software**: TIFI está en desarrollo activo
- **Testnet**: Actualmente en fase de prueba
- **Seguridad**: Mantén tu seed phrase seguro
- **Backups**: Haz backups regulares de tu wallet
- **No para producción**: No usar con fondos reales aún

## 📄 Licencia

MIT License - Ver archivo LICENSE para detalles

## 🤝 Soporte

- **Issues**: GitHub Issues
- **Documentación**: Ver carpeta `docs/`
- **Comunidad**: [Discord/Telegram - TODO]

## 🌟 Créditos

TIFI - Time Fidelity Blockchain

Desarrollado con ❤️ para la comunidad blockchain

---

**"Como una flor, donde el software es ejecutado, así crece la red"**
