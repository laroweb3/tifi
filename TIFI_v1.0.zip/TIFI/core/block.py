"""
TIFI Blockchain - Block Module
Maneja la estructura y validación de bloques
"""

import hashlib
import json
import time
from typing import List, Dict, Optional
from transaction import Transaction


class BlockHeader:
    """Encabezado del bloque"""
    
    def __init__(
        self,
        version: int,
        previous_hash: str,
        merkle_root: str,
        timestamp: float,
        difficulty: int,
        nonce: int = 0,
        block_type: str = "pow",  # pow o pos
        stake_data: Optional[Dict] = None
    ):
        self.version = version
        self.previous_hash = previous_hash
        self.merkle_root = merkle_root
        self.timestamp = timestamp
        self.difficulty = difficulty
        self.nonce = nonce
        self.block_type = block_type
        self.stake_data = stake_data or {}
    
    def to_dict(self) -> Dict:
        return {
            "version": self.version,
            "previous_hash": self.previous_hash,
            "merkle_root": self.merkle_root,
            "timestamp": self.timestamp,
            "difficulty": self.difficulty,
            "nonce": self.nonce,
            "block_type": self.block_type,
            "stake_data": self.stake_data
        }
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(
            version=data["version"],
            previous_hash=data["previous_hash"],
            merkle_root=data["merkle_root"],
            timestamp=data["timestamp"],
            difficulty=data["difficulty"],
            nonce=data.get("nonce", 0),
            block_type=data.get("block_type", "pow"),
            stake_data=data.get("stake_data", {})
        )


class Block:
    """Bloque en la blockchain TIFI"""
    
    VERSION = 1
    MAX_TRANSACTIONS = 2000
    MAX_BLOCK_SIZE = 1_000_000  # 1MB
    
    def __init__(
        self,
        header: BlockHeader,
        transactions: List[Transaction],
        height: int = 0,
        signature: str = ""
    ):
        self.header = header
        self.transactions = transactions
        self.height = height
        self.signature = signature  # Solo para bloques PoS
        self.block_hash = ""
    
    def calculate_hash(self) -> str:
        """Calcula el hash del bloque"""
        header_string = json.dumps(self.header.to_dict(), sort_keys=True)
        return hashlib.sha256(hashlib.sha256(header_string.encode()).digest()).hexdigest()
    
    def calculate_merkle_root(self) -> str:
        """Calcula el merkle root de las transacciones"""
        if not self.transactions:
            return hashlib.sha256(b"").hexdigest()
        
        # Obtener hashes de todas las transacciones
        tx_hashes = [tx.tx_id for tx in self.transactions]
        
        # Construir árbol de Merkle
        while len(tx_hashes) > 1:
            if len(tx_hashes) % 2 != 0:
                tx_hashes.append(tx_hashes[-1])  # Duplicar último si es impar
            
            new_hashes = []
            for i in range(0, len(tx_hashes), 2):
                combined = tx_hashes[i] + tx_hashes[i + 1]
                new_hash = hashlib.sha256(combined.encode()).hexdigest()
                new_hashes.append(new_hash)
            
            tx_hashes = new_hashes
        
        return tx_hashes[0]
    
    def get_target(self) -> int:
        """Calcula el target basado en la dificultad"""
        # Target = 2^(256 - difficulty)
        return 2 ** (256 - self.header.difficulty)
    
    def is_valid_pow(self) -> bool:
        """Verifica si el hash cumple con la dificultad PoW"""
        if self.header.block_type != "pow":
            return True  # No es bloque PoW
        
        block_hash_int = int(self.block_hash, 16)
        target = self.get_target()
        return block_hash_int < target
    
    def is_valid_pos(self) -> bool:
        """Verifica si el bloque PoS es válido"""
        if self.header.block_type != "pos":
            return True  # No es bloque PoS
        
        # Verificar que tenga stake_data
        if not self.header.stake_data:
            return False
        
        # Verificar firma del validador (se implementará con crypto)
        # TODO: Verificar self.signature con stake_data["validator_pubkey"]
        
        return True
    
    def validate_basic(self) -> bool:
        """Validación básica del bloque"""
        # Verificar versión
        if self.header.version != self.VERSION:
            return False
        
        # Verificar que tenga transacciones
        if not self.transactions:
            return False
        
        # Verificar límite de transacciones
        if len(self.transactions) > self.MAX_TRANSACTIONS:
            return False
        
        # Verificar que la primera transacción sea coinbase o stake reward
        if not (self.transactions[0].is_coinbase() or self.transactions[0].is_stake()):
            return False
        
        # Verificar que solo la primera sea coinbase/stake
        for tx in self.transactions[1:]:
            if tx.is_coinbase() or tx.is_stake():
                return False
        
        # Verificar merkle root
        calculated_merkle = self.calculate_merkle_root()
        if self.header.merkle_root != calculated_merkle:
            return False
        
        # Verificar hash del bloque
        calculated_hash = self.calculate_hash()
        if self.block_hash and self.block_hash != calculated_hash:
            return False
        
        # Verificar PoW o PoS según tipo
        if self.header.block_type == "pow":
            if not self.is_valid_pow():
                return False
        elif self.header.block_type == "pos":
            if not self.is_valid_pos():
                return False
        
        return True
    
    def validate_transactions(self, utxo_set: Dict) -> bool:
        """Valida todas las transacciones del bloque"""
        for i, tx in enumerate(self.transactions):
            # Primera transacción (coinbase/stake) solo validación básica
            if i == 0:
                if not tx.validate_basic():
                    return False
            else:
                # Resto de transacciones validación completa
                if not tx.validate_full(utxo_set):
                    return False
        
        return True
    
    def get_size(self) -> int:
        """Calcula el tamaño del bloque en bytes"""
        block_data = self.to_dict()
        return len(json.dumps(block_data).encode())
    
    def to_dict(self) -> Dict:
        """Convierte el bloque a diccionario"""
        return {
            "header": self.header.to_dict(),
            "transactions": [tx.to_dict() for tx in self.transactions],
            "height": self.height,
            "signature": self.signature,
            "block_hash": self.block_hash
        }
    
    @classmethod
    def from_dict(cls, data: Dict):
        """Crea un bloque desde un diccionario"""
        header = BlockHeader.from_dict(data["header"])
        transactions = [Transaction.from_dict(tx) for tx in data["transactions"]]
        block = cls(
            header=header,
            transactions=transactions,
            height=data.get("height", 0),
            signature=data.get("signature", "")
        )
        block.block_hash = data.get("block_hash", "")
        return block
    
    @staticmethod
    def create_genesis_block() -> 'Block':
        """Crea el bloque génesis"""
        # Transacción coinbase inicial
        genesis_address = "T1GENESIS1111111111111111111111111111"
        coinbase = Transaction.create_coinbase(
            miner_address=genesis_address,
            reward=50.0,
            block_height=0
        )
        
        # Header del bloque génesis
        header = BlockHeader(
            version=Block.VERSION,
            previous_hash="0" * 64,
            merkle_root="",
            timestamp=1700000000.0,  # Timestamp fijo para génesis
            difficulty=20,  # Dificultad inicial
            nonce=0,
            block_type="pow"
        )
        
        # Crear bloque
        genesis = Block(
            header=header,
            transactions=[coinbase],
            height=0
        )
        
        # Calcular merkle root
        genesis.header.merkle_root = genesis.calculate_merkle_root()
        
        # Calcular hash
        genesis.block_hash = genesis.calculate_hash()
        
        return genesis
    
    @staticmethod
    def create_pow_block(
        previous_hash: str,
        transactions: List[Transaction],
        difficulty: int,
        height: int
    ) -> 'Block':
        """Crea un nuevo bloque PoW"""
        header = BlockHeader(
            version=Block.VERSION,
            previous_hash=previous_hash,
            merkle_root="",
            timestamp=time.time(),
            difficulty=difficulty,
            nonce=0,
            block_type="pow"
        )
        
        block = Block(
            header=header,
            transactions=transactions,
            height=height
        )
        
        # Calcular merkle root
        block.header.merkle_root = block.calculate_merkle_root()
        
        return block
    
    @staticmethod
    def create_pos_block(
        previous_hash: str,
        transactions: List[Transaction],
        difficulty: int,
        height: int,
        validator_address: str,
        stake_amount: float
    ) -> 'Block':
        """Crea un nuevo bloque PoS"""
        stake_data = {
            "validator_address": validator_address,
            "stake_amount": stake_amount
        }
        
        header = BlockHeader(
            version=Block.VERSION,
            previous_hash=previous_hash,
            merkle_root="",
            timestamp=time.time(),
            difficulty=difficulty,
            nonce=0,
            block_type="pos",
            stake_data=stake_data
        )
        
        block = Block(
            header=header,
            transactions=transactions,
            height=height
        )
        
        # Calcular merkle root
        block.header.merkle_root = block.calculate_merkle_root()
        
        return block
    
    def __repr__(self) -> str:
        return f"Block(height={self.height}, hash={self.block_hash[:8]}..., txs={len(self.transactions)}, type={self.header.block_type})"
