"""
TIFI Blockchain - Consensus Module
Implementa el mecanismo de consenso híbrido PoW/PoS
"""

import hashlib
import random
import time
from typing import Dict, List, Optional, Tuple
from block import Block
from transaction import Transaction


class ProofOfWork:
    """Implementación de Proof of Work"""
    
    @staticmethod
    def mine_block(block: Block, stop_flag: callable = None) -> Tuple[bool, int]:
        """
        Mina un bloque PoW incrementando el nonce hasta encontrar un hash válido
        
        Args:
            block: Bloque a minar
            stop_flag: Función que retorna True si se debe detener la minería
        
        Returns:
            (success, nonce): Tupla con éxito y nonce encontrado
        """
        target = block.get_target()
        nonce = 0
        max_nonce = 2 ** 32  # 4 billones
        
        start_time = time.time()
        hashes_calculated = 0
        
        while nonce < max_nonce:
            # Verificar si se debe detener
            if stop_flag and stop_flag():
                return False, nonce
            
            # Actualizar nonce
            block.header.nonce = nonce
            
            # Calcular hash
            block_hash = block.calculate_hash()
            block_hash_int = int(block_hash, 16)
            
            hashes_calculated += 1
            
            # Verificar si cumple con el target
            if block_hash_int < target:
                block.block_hash = block_hash
                
                # Estadísticas
                elapsed = time.time() - start_time
                hashrate = hashes_calculated / elapsed if elapsed > 0 else 0
                
                print(f"✓ Bloque minado!")
                print(f"  Hash: {block_hash}")
                print(f"  Nonce: {nonce}")
                print(f"  Tiempo: {elapsed:.2f}s")
                print(f"  Hashrate: {hashrate:.2f} H/s")
                
                return True, nonce
            
            nonce += 1
            
            # Mostrar progreso cada 100k hashes
            if hashes_calculated % 100000 == 0:
                elapsed = time.time() - start_time
                hashrate = hashes_calculated / elapsed if elapsed > 0 else 0
                print(f"  Minando... {hashes_calculated} hashes, {hashrate:.2f} H/s")
        
        return False, nonce
    
    @staticmethod
    def verify_pow(block: Block) -> bool:
        """Verifica que un bloque cumpla con la prueba de trabajo"""
        if block.header.block_type != "pow":
            return True
        
        # Recalcular hash
        calculated_hash = block.calculate_hash()
        if calculated_hash != block.block_hash:
            return False
        
        # Verificar que cumpla con el target
        block_hash_int = int(block.block_hash, 16)
        target = block.get_target()
        
        return block_hash_int < target
    
    @staticmethod
    def estimate_time_to_mine(difficulty: int, hashrate: float) -> float:
        """
        Estima el tiempo para minar un bloque
        
        Args:
            difficulty: Dificultad actual
            hashrate: Hashrate en H/s
        
        Returns:
            Tiempo estimado en segundos
        """
        target = 2 ** (256 - difficulty)
        max_hash = 2 ** 256
        probability = target / max_hash
        expected_hashes = 1 / probability
        
        if hashrate > 0:
            return expected_hashes / hashrate
        return float('inf')


class ProofOfStake:
    """Implementación de Proof of Stake"""
    
    MIN_STAKE = 100.0  # CRED mínimos para hacer stake
    STAKE_REWARD_RATE = 0.05  # 5% anual
    MATURATION_BLOCKS = 100  # Bloques para madurar stake
    MAX_COIN_AGE_DAYS = 30  # Máximo coin age
    
    def __init__(self, blockchain):
        self.blockchain = blockchain
        self.stake_pool: Dict[str, Dict] = {}  # address -> stake info
    
    def add_stake(self, address: str, amount: float, block_height: int) -> bool:
        """Añade stake para una dirección"""
        if amount < self.MIN_STAKE:
            return False
        
        # Verificar que tenga fondos suficientes
        balance = self.blockchain.get_balance(address)
        if balance < amount:
            return False
        
        # Añadir o actualizar stake
        if address in self.stake_pool:
            self.stake_pool[address]["amount"] += amount
        else:
            self.stake_pool[address] = {
                "amount": amount,
                "start_height": block_height,
                "last_reward_height": block_height
            }
        
        return True
    
    def remove_stake(self, address: str, amount: float) -> bool:
        """Remueve stake de una dirección"""
        if address not in self.stake_pool:
            return False
        
        stake_info = self.stake_pool[address]
        
        if stake_info["amount"] < amount:
            return False
        
        stake_info["amount"] -= amount
        
        # Remover completamente si llega a 0
        if stake_info["amount"] < self.MIN_STAKE:
            del self.stake_pool[address]
        
        return True
    
    def calculate_coin_age(self, address: str, current_height: int) -> float:
        """Calcula el coin age de un stake"""
        if address not in self.stake_pool:
            return 0.0
        
        stake_info = self.stake_pool[address]
        blocks_staked = current_height - stake_info["start_height"]
        
        # Convertir bloques a días (asumiendo 1 bloque por minuto)
        days_staked = blocks_staked / (60 * 24)
        
        # Limitar a MAX_COIN_AGE_DAYS
        days_staked = min(days_staked, self.MAX_COIN_AGE_DAYS)
        
        # Coin age = amount × days
        coin_age = stake_info["amount"] * days_staked
        
        return coin_age
    
    def is_stake_mature(self, address: str, current_height: int) -> bool:
        """Verifica si un stake ha madurado"""
        if address not in self.stake_pool:
            return False
        
        stake_info = self.stake_pool[address]
        blocks_staked = current_height - stake_info["start_height"]
        
        return blocks_staked >= self.MATURATION_BLOCKS
    
    def select_validator(self, current_height: int, previous_hash: str) -> Optional[str]:
        """
        Selecciona un validador para crear el siguiente bloque PoS
        Usa weighted random basado en stake + coin age
        """
        # Filtrar stakes maduros
        eligible_stakers = []
        weights = []
        
        for address, stake_info in self.stake_pool.items():
            if self.is_stake_mature(address, current_height):
                coin_age = self.calculate_coin_age(address, current_height)
                weight = stake_info["amount"] + coin_age
                
                eligible_stakers.append(address)
                weights.append(weight)
        
        if not eligible_stakers:
            return None
        
        # Usar previous_hash como seed para determinismo
        seed = int(previous_hash[:16], 16)
        random.seed(seed)
        
        # Selección weighted random
        total_weight = sum(weights)
        normalized_weights = [w / total_weight for w in weights]
        
        validator = random.choices(eligible_stakers, weights=normalized_weights, k=1)[0]
        
        return validator
    
    def calculate_stake_reward(self, address: str, current_height: int) -> float:
        """Calcula la recompensa de stake"""
        if address not in self.stake_pool:
            return 0.0
        
        stake_info = self.stake_pool[address]
        
        # Bloques desde última recompensa
        blocks_since_reward = current_height - stake_info["last_reward_height"]
        
        # Convertir a años (asumiendo 1 bloque por minuto)
        years = blocks_since_reward / (60 * 24 * 365)
        
        # Recompensa = stake × rate × time
        reward = stake_info["amount"] * self.STAKE_REWARD_RATE * years
        
        return reward
    
    def create_pos_block(
        self,
        validator_address: str,
        transactions: List[Transaction],
        previous_block: Block
    ) -> Optional[Block]:
        """Crea un bloque PoS"""
        # Verificar que el validador tenga stake
        if validator_address not in self.stake_pool:
            return None
        
        stake_info = self.stake_pool[validator_address]
        current_height = previous_block.height + 1
        
        # Verificar que el stake esté maduro
        if not self.is_stake_mature(validator_address, current_height):
            return None
        
        # Calcular recompensa
        reward = self.calculate_stake_reward(validator_address, current_height)
        
        # Crear transacción de recompensa
        reward_tx = Transaction.create_stake_reward(validator_address, reward)
        
        # Insertar recompensa al inicio
        all_transactions = [reward_tx] + transactions
        
        # Crear bloque
        block = Block.create_pos_block(
            previous_hash=previous_block.block_hash,
            transactions=all_transactions,
            difficulty=self.blockchain.get_difficulty(),
            height=current_height,
            validator_address=validator_address,
            stake_amount=stake_info["amount"]
        )
        
        # Calcular hash
        block.block_hash = block.calculate_hash()
        
        # Actualizar última recompensa
        stake_info["last_reward_height"] = current_height
        
        return block
    
    def verify_pos(self, block: Block) -> bool:
        """Verifica que un bloque PoS sea válido"""
        if block.header.block_type != "pos":
            return True
        
        # Verificar que tenga stake_data
        if not block.header.stake_data:
            return False
        
        validator_address = block.header.stake_data.get("validator_address")
        stake_amount = block.header.stake_data.get("stake_amount")
        
        if not validator_address or not stake_amount:
            return False
        
        # Verificar que el validador tenga stake suficiente
        if validator_address not in self.stake_pool:
            return False
        
        actual_stake = self.stake_pool[validator_address]["amount"]
        if actual_stake < stake_amount:
            return False
        
        # Verificar que el validador fue correctamente seleccionado
        previous_block = self.blockchain.get_block_by_height(block.height - 1)
        if not previous_block:
            return False
        
        expected_validator = self.select_validator(block.height, previous_block.block_hash)
        if expected_validator != validator_address:
            return False
        
        return True
    
    def get_stake_info(self, address: str) -> Optional[Dict]:
        """Obtiene información de stake de una dirección"""
        if address not in self.stake_pool:
            return None
        
        stake_info = self.stake_pool[address].copy()
        current_height = self.blockchain.get_height()
        
        stake_info["coin_age"] = self.calculate_coin_age(address, current_height)
        stake_info["is_mature"] = self.is_stake_mature(address, current_height)
        stake_info["pending_reward"] = self.calculate_stake_reward(address, current_height)
        
        return stake_info
    
    def get_all_stakes(self) -> Dict[str, Dict]:
        """Obtiene todos los stakes activos"""
        current_height = self.blockchain.get_height()
        
        result = {}
        for address in self.stake_pool:
            result[address] = self.get_stake_info(address)
        
        return result
    
    def get_total_staked(self) -> float:
        """Calcula el total de CRED en stake"""
        return sum(info["amount"] for info in self.stake_pool.values())


class HybridConsensus:
    """Consenso híbrido PoW/PoS"""
    
    def __init__(self, blockchain):
        self.blockchain = blockchain
        self.pow = ProofOfWork()
        self.pos = ProofOfStake(blockchain)
    
    def create_next_block(
        self,
        miner_address: str,
        transactions: List[Transaction]
    ) -> Optional[Block]:
        """Crea el siguiente bloque según el tipo que corresponda"""
        latest_block = self.blockchain.get_latest_block()
        next_height = latest_block.height + 1
        block_type = self.blockchain.get_next_block_type()
        
        # Calcular recompensa base
        reward = self.blockchain.get_block_reward(next_height)
        
        # Calcular fees
        total_fees = sum(tx.get_fee(self.blockchain.utxo_set) for tx in transactions)
        total_reward = reward + total_fees
        
        if block_type == "pow":
            # Crear transacción coinbase
            coinbase = Transaction.create_coinbase(miner_address, total_reward, next_height)
            all_transactions = [coinbase] + transactions
            
            # Crear bloque PoW
            block = Block.create_pow_block(
                previous_hash=latest_block.block_hash,
                transactions=all_transactions,
                difficulty=self.blockchain.get_difficulty(),
                height=next_height
            )
            
            return block
        
        elif block_type == "pos":
            # Seleccionar validador
            validator = self.pos.select_validator(next_height, latest_block.block_hash)
            
            if not validator:
                print("No hay validadores elegibles para PoS")
                return None
            
            # Crear bloque PoS
            block = self.pos.create_pos_block(validator, transactions, latest_block)
            
            return block
        
        return None
    
    def mine_block(self, block: Block, stop_flag: callable = None) -> bool:
        """Mina un bloque (solo para PoW)"""
        if block.header.block_type != "pow":
            return False
        
        success, nonce = self.pow.mine_block(block, stop_flag)
        return success
    
    def verify_block(self, block: Block) -> bool:
        """Verifica un bloque según su tipo"""
        if block.header.block_type == "pow":
            return self.pow.verify_pow(block)
        elif block.header.block_type == "pos":
            return self.pos.verify_pos(block)
        return False
    
    def get_consensus_stats(self) -> Dict:
        """Obtiene estadísticas del consenso"""
        height = self.blockchain.get_height()
        
        # Contar bloques PoW y PoS
        pow_blocks = 0
        pos_blocks = 0
        
        for block in self.blockchain.chain:
            if block.header.block_type == "pow":
                pow_blocks += 1
            elif block.header.block_type == "pos":
                pos_blocks += 1
        
        return {
            "pow_blocks": pow_blocks,
            "pos_blocks": pos_blocks,
            "total_blocks": height + 1,
            "next_block_type": self.blockchain.get_next_block_type(),
            "total_staked": self.pos.get_total_staked(),
            "active_stakers": len(self.pos.stake_pool)
        }
