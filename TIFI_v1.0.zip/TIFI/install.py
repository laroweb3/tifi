#!/usr/bin/env python3
"""
TIFI - Instalador Universal
Detecta el sistema operativo y ejecuta el instalador correspondiente
"""

import os
import sys
import platform
import subprocess


def detect_os():
    """Detecta el sistema operativo"""
    system = platform.system()
    
    if system == "Linux":
        return "linux"
    elif system == "Windows":
        return "windows"
    elif system == "Darwin":
        return "macos"
    else:
        return "unknown"


def install_linux():
    """Instalación en Linux"""
    print("Sistema operativo: Linux")
    print("\nEjecutando instalador de Linux...")
    
    installer_path = os.path.join(os.path.dirname(__file__), "installer", "linux", "install.sh")
    
    if not os.path.exists(installer_path):
        print(f"❌ Error: Instalador no encontrado en {installer_path}")
        return False
    
    # Verificar si se ejecuta como root
    if os.geteuid() != 0:
        print("\n⚠️  Se requieren permisos de administrador")
        print("Ejecuta: sudo python3 install.py")
        return False
    
    # Ejecutar instalador
    result = subprocess.run(["bash", installer_path])
    return result.returncode == 0


def install_windows():
    """Instalación en Windows"""
    print("Sistema operativo: Windows")
    print("\nEjecutando instalador de Windows...")
    
    installer_path = os.path.join(os.path.dirname(__file__), "installer", "windows", "install.bat")
    
    if not os.path.exists(installer_path):
        print(f"❌ Error: Instalador no encontrado en {installer_path}")
        return False
    
    # Ejecutar instalador
    result = subprocess.run([installer_path], shell=True)
    return result.returncode == 0


def install_macos():
    """Instalación en macOS"""
    print("Sistema operativo: macOS")
    print("\n⚠️  Instalador para macOS no disponible aún")
    print("\nInstalación manual:")
    print("1. Instala Python 3.8+ desde python.org")
    print("2. Instala dependencias: pip3 install ecdsa base58 mnemonic")
    print("3. Ejecuta: python3 tifi_node.py")
    return False


def main():
    print("="*60)
    print("  TIFI - Time Fidelity Blockchain")
    print("  Instalador Universal")
    print("="*60)
    print()
    
    # Detectar sistema operativo
    os_type = detect_os()
    
    if os_type == "linux":
        success = install_linux()
    elif os_type == "windows":
        success = install_windows()
    elif os_type == "macos":
        success = install_macos()
    else:
        print(f"❌ Sistema operativo no soportado: {platform.system()}")
        success = False
    
    if success:
        print("\n✓ Instalación completada exitosamente")
        return 0
    else:
        print("\n❌ La instalación falló o fue cancelada")
        return 1


if __name__ == "__main__":
    sys.exit(main())
