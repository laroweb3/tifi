"""
TIFI Blockchain - Staking Module
Sistema de staking para participar en consenso PoS
"""

import time
import threading
from typing import Optional, Dict, List


class StakingManager:
    """Gestor de staking"""
    
    def __init__(self, blockchain, wallet, consensus):
        self.blockchain = blockchain
        self.wallet = wallet
        self.consensus = consensus
        
        self.staking = False
        self.staking_thread: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()
        
        # Estadísticas
        self.blocks_validated = 0
        self.total_rewards = 0.0
        self.start_time = 0.0
        
        # Stakes activos
        self.active_stakes: Dict[str, float] = {}  # address -> amount
    
    def add_stake(self, address: str, amount: float) -> bool:
        """
        Añade stake para una dirección
        
        Args:
            address: Dirección a hacer stake
            amount: Cantidad de CRED a hacer stake
        
        Returns:
            True si el stake fue exitoso
        """
        # Verificar balance
        balance = self.blockchain.get_balance(address)
        
        if balance < amount:
            print(f"Balance insuficiente: {balance} CRED disponibles")
            return False
        
        # Verificar mínimo
        if amount < self.consensus.pos.MIN_STAKE:
            print(f"Stake mínimo: {self.consensus.pos.MIN_STAKE} CRED")
            return False
        
        # Añadir stake
        current_height = self.blockchain.get_height()
        success = self.consensus.pos.add_stake(address, amount, current_height)
        
        if success:
            self.active_stakes[address] = amount
            print(f"✓ Stake añadido: {amount} CRED desde {address}")
            print(f"  Maduración en {self.consensus.pos.MATURATION_BLOCKS} bloques")
            return True
        else:
            print("✗ Error añadiendo stake")
            return False
    
    def remove_stake(self, address: str, amount: float) -> bool:
        """
        Remueve stake de una dirección
        
        Args:
            address: Dirección del stake
            amount: Cantidad a remover
        
        Returns:
            True si fue exitoso
        """
        success = self.consensus.pos.remove_stake(address, amount)
        
        if success:
            if address in self.active_stakes:
                self.active_stakes[address] -= amount
                if self.active_stakes[address] <= 0:
                    del self.active_stakes[address]
            
            print(f"✓ Stake removido: {amount} CRED de {address}")
            return True
        else:
            print("✗ Error removiendo stake")
            return False
    
    def start_staking(self):
        """Inicia el proceso de staking"""
        if self.staking:
            print("Staking ya está en ejecución")
            return
        
        if not self.active_stakes:
            print("No hay stakes activos. Añade stake primero con add_stake()")
            return
        
        print(f"Iniciando staking con {len(self.active_stakes)} direcciones...")
        
        self.staking = True
        self.stop_flag.clear()
        self.start_time = time.time()
        
        # Iniciar thread de staking
        self.staking_thread = threading.Thread(target=self._staking_loop, daemon=True)
        self.staking_thread.start()
        
        print("✓ Staking iniciado")
    
    def stop_staking(self):
        """Detiene el staking"""
        if not self.staking:
            return
        
        print("Deteniendo staking...")
        self.staking = False
        self.stop_flag.set()
        
        if self.staking_thread:
            self.staking_thread.join(timeout=5)
        
        print("✓ Staking detenido")
    
    def _staking_loop(self):
        """Loop principal de staking"""
        while self.staking:
            try:
                # Verificar si debemos validar un bloque PoS
                next_block_type = self.blockchain.get_next_block_type()
                
                if next_block_type != "pos":
                    # No es turno de PoS, esperar
                    time.sleep(10)
                    continue
                
                # Verificar si alguna de nuestras direcciones es seleccionada
                latest_block = self.blockchain.get_latest_block()
                next_height = latest_block.height + 1
                
                selected_validator = self.consensus.pos.select_validator(
                    next_height,
                    latest_block.block_hash
                )
                
                if selected_validator in self.active_stakes:
                    print(f"\n[Staking] ¡Seleccionado como validador!")
                    print(f"  Dirección: {selected_validator}")
                    
                    # Obtener transacciones del mempool
                    transactions = self.blockchain.transaction_pool.get_transactions(500)
                    
                    # Crear bloque PoS
                    block = self.consensus.pos.create_pos_block(
                        validator_address=selected_validator,
                        transactions=transactions,
                        previous_block=latest_block
                    )
                    
                    if block:
                        # Añadir a la blockchain
                        if self.blockchain.add_block(block):
                            reward = block.transactions[0].get_output_sum()
                            self.blocks_validated += 1
                            self.total_rewards += reward
                            
                            print(f"\n{'='*60}")
                            print(f"  ✨ ¡BLOQUE VALIDADO! ✨")
                            print(f"{'='*60}")
                            print(f"  Altura: {block.height}")
                            print(f"  Hash: {block.block_hash}")
                            print(f"  Recompensa: {reward:.4f} CRED")
                            print(f"  Total bloques validados: {self.blocks_validated}")
                            print(f"  Total recompensas: {self.total_rewards:.4f} CRED")
                            print(f"{'='*60}\n")
                            
                            # TODO: Broadcast del bloque a la red
                        else:
                            print("✗ Bloque rechazado por la blockchain")
                    else:
                        print("✗ Error creando bloque PoS")
                
                # Esperar un poco antes de verificar de nuevo
                time.sleep(5)
            
            except Exception as e:
                print(f"Error en staking: {e}")
                time.sleep(5)
    
    def get_stake_info(self, address: str) -> Optional[Dict]:
        """Obtiene información de stake de una dirección"""
        return self.consensus.pos.get_stake_info(address)
    
    def get_all_stakes(self) -> Dict[str, Dict]:
        """Obtiene información de todos los stakes"""
        return self.consensus.pos.get_all_stakes()
    
    def get_my_stakes(self) -> List[Dict]:
        """Obtiene información de los stakes de este wallet"""
        my_stakes = []
        
        for address in self.wallet.get_all_addresses():
            stake_info = self.get_stake_info(address)
            if stake_info:
                my_stakes.append({
                    "address": address,
                    "label": self.wallet.get_label(address),
                    **stake_info
                })
        
        return my_stakes
    
    def calculate_expected_return(self, amount: float, days: int = 365) -> float:
        """
        Calcula el retorno esperado de staking
        
        Args:
            amount: Cantidad a hacer stake
            days: Días de staking
        
        Returns:
            Retorno esperado en CRED
        """
        years = days / 365
        return amount * self.consensus.pos.STAKE_REWARD_RATE * years
    
    def get_stats(self) -> dict:
        """Obtiene estadísticas de staking"""
        uptime = time.time() - self.start_time if self.start_time > 0 else 0
        
        total_staked = sum(self.active_stakes.values())
        network_total_staked = self.consensus.pos.get_total_staked()
        
        stake_percentage = 0.0
        if network_total_staked > 0:
            stake_percentage = (total_staked / network_total_staked) * 100
        
        return {
            "staking": self.staking,
            "active_addresses": len(self.active_stakes),
            "total_staked": total_staked,
            "network_total_staked": network_total_staked,
            "stake_percentage": stake_percentage,
            "blocks_validated": self.blocks_validated,
            "total_rewards": self.total_rewards,
            "uptime": uptime,
            "next_block_type": self.blockchain.get_next_block_type()
        }
    
    def is_staking(self) -> bool:
        """Verifica si está haciendo staking"""
        return self.staking
    
    def auto_stake_all(self, reserve: float = 10.0) -> bool:
        """
        Hace stake automático de todos los fondos disponibles
        
        Args:
            reserve: Cantidad a mantener sin stake (para fees)
        
        Returns:
            True si se añadió al menos un stake
        """
        success_count = 0
        
        for address in self.wallet.get_all_addresses():
            balance = self.blockchain.get_balance(address)
            
            # Calcular cantidad a hacer stake
            stakeable = balance - reserve
            
            if stakeable >= self.consensus.pos.MIN_STAKE:
                if self.add_stake(address, stakeable):
                    success_count += 1
        
        if success_count > 0:
            print(f"✓ Auto-stake completado: {success_count} direcciones")
            return True
        else:
            print("No hay fondos suficientes para hacer stake")
            return False
    
    def __repr__(self) -> str:
        status = "ACTIVO" if self.staking else "INACTIVO"
        total = sum(self.active_stakes.values())
        return f"StakingManager(status={status}, staked={total:.2f} CRED, blocks={self.blocks_validated})"
