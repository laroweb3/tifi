#!/usr/bin/env python3
"""
TIFI CLI - Interfaz de línea de comandos
Permite interactuar con un nodo TIFI en ejecución
"""

import sys
import os
import argparse

# Añadir directorios al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'core'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'wallet'))

from blockchain import Blockchain
from wallet import Wallet


def main():
    parser = argparse.ArgumentParser(description='TIFI CLI - Interfaz de línea de comandos')
    parser.add_argument('--datadir', default='~/.tifi', help='Directorio de datos')
    
    subparsers = parser.add_subparsers(dest='command', help='Comandos disponibles')
    
    # Comando: getinfo
    subparsers.add_parser('getinfo', help='Obtiene información del nodo')
    
    # Comando: getbalance
    subparsers.add_parser('getbalance', help='Obtiene el balance del wallet')
    
    # Comando: getnewaddress
    getnewaddress_parser = subparsers.add_parser('getnewaddress', help='Genera una nueva dirección')
    getnewaddress_parser.add_argument('--label', default='', help='Etiqueta para la dirección')
    
    # Comando: listaddresses
    subparsers.add_parser('listaddresses', help='Lista todas las direcciones')
    
    # Comando: send
    send_parser = subparsers.add_parser('send', help='Envía CRED a una dirección')
    send_parser.add_argument('address', help='Dirección destino')
    send_parser.add_argument('amount', type=float, help='Cantidad a enviar')
    send_parser.add_argument('--fee', type=float, default=0.001, help='Fee de transacción')
    
    # Comando: listtransactions
    subparsers.add_parser('listtransactions', help='Lista transacciones recientes')
    
    # Comando: getblockcount
    subparsers.add_parser('getblockcount', help='Obtiene la altura de la blockchain')
    
    # Comando: getblock
    getblock_parser = subparsers.add_parser('getblock', help='Obtiene información de un bloque')
    getblock_parser.add_argument('height', type=int, help='Altura del bloque')
    
    # Comando: exportprivkey
    exportprivkey_parser = subparsers.add_parser('exportprivkey', help='Exporta clave privada')
    exportprivkey_parser.add_argument('address', help='Dirección')
    exportprivkey_parser.add_argument('--format', default='hex', choices=['hex', 'wif'], help='Formato')
    
    # Comando: importprivkey
    importprivkey_parser = subparsers.add_parser('importprivkey', help='Importa clave privada')
    importprivkey_parser.add_argument('privkey', help='Clave privada (hex o WIF)')
    importprivkey_parser.add_argument('--label', default='', help='Etiqueta')
    
    # Comando: backupwallet
    backupwallet_parser = subparsers.add_parser('backupwallet', help='Crea backup del wallet')
    backupwallet_parser.add_argument('destination', help='Ruta del backup')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Inicializar blockchain y wallet
    data_dir = os.path.expanduser(args.datadir)
    blockchain = Blockchain(data_dir)
    wallet = Wallet(blockchain, data_dir)
    
    # Ejecutar comando
    if args.command == 'getinfo':
        stats = blockchain.get_network_stats()
        wallet_info = wallet.get_wallet_info()
        
        print("\n=== Información del Nodo TIFI ===")
        print(f"Altura de blockchain: {stats['height']}")
        print(f"Dificultad: {stats['difficulty']}")
        print(f"Supply total: {stats['total_supply']:.2f} CRED")
        print(f"Supply máximo: {stats['max_supply']:,.0f} CRED")
        print(f"Recompensa de bloque: {stats['block_reward']:.2f} CRED")
        print(f"Mempool: {stats['mempool_size']} transacciones")
        print(f"\nWallet:")
        print(f"  Direcciones: {wallet_info['addresses']}")
        print(f"  Balance: {wallet_info['balance']:.4f} CRED")
    
    elif args.command == 'getbalance':
        balance = wallet.get_balance()
        print(f"\nBalance: {balance:.4f} CRED")
    
    elif args.command == 'getnewaddress':
        address = wallet.get_new_address(args.label)
        print(f"\nNueva dirección: {address}")
        if args.label:
            print(f"Etiqueta: {args.label}")
    
    elif args.command == 'listaddresses':
        details = wallet.get_balance_details()
        
        print("\n=== Direcciones del Wallet ===")
        for detail in details:
            print(f"\nDirección: {detail['address']}")
            if detail['label']:
                print(f"Etiqueta: {detail['label']}")
            print(f"Balance: {detail['balance']:.4f} CRED")
    
    elif args.command == 'send':
        print(f"\nEnviando {args.amount} CRED a {args.address}...")
        success = wallet.send(args.address, args.amount, args.fee)
        
        if success:
            print("✓ Transacción enviada correctamente")
        else:
            print("✗ Error enviando transacción")
    
    elif args.command == 'listtransactions':
        history = wallet.get_transaction_history()
        
        print("\n=== Historial de Transacciones ===")
        for tx in history[:20]:  # Últimas 20
            from datetime import datetime
            timestamp = datetime.fromtimestamp(tx['timestamp']).strftime('%Y-%m-%d %H:%M:%S')
            
            print(f"\nTX: {tx['tx_id'][:16]}...")
            print(f"Tipo: {tx['type']}")
            print(f"Cantidad: {tx['amount']:.4f} CRED")
            print(f"Fecha: {timestamp}")
            print(f"Bloque: {tx['block_height']}")
    
    elif args.command == 'getblockcount':
        height = blockchain.get_height()
        print(f"\nAltura de blockchain: {height}")
    
    elif args.command == 'getblock':
        block = blockchain.get_block_by_height(args.height)
        
        if block:
            print(f"\n=== Bloque #{block.height} ===")
            print(f"Hash: {block.block_hash}")
            print(f"Hash anterior: {block.header.previous_hash}")
            print(f"Merkle root: {block.header.merkle_root}")
            print(f"Timestamp: {block.header.timestamp}")
            print(f"Dificultad: {block.header.difficulty}")
            print(f"Nonce: {block.header.nonce}")
            print(f"Tipo: {block.header.block_type}")
            print(f"Transacciones: {len(block.transactions)}")
        else:
            print(f"\n✗ Bloque {args.height} no encontrado")
    
    elif args.command == 'exportprivkey':
        privkey = wallet.export_private_key(args.address, args.format)
        
        if privkey:
            print(f"\n⚠️  CLAVE PRIVADA - MANTENER SEGURA ⚠️")
            print(f"\nDirección: {args.address}")
            print(f"Formato: {args.format}")
            print(f"Clave: {privkey}")
            print(f"\n⚠️  NO COMPARTIR CON NADIE ⚠️")
        else:
            print(f"\n✗ No se encontró clave privada para {args.address}")
    
    elif args.command == 'importprivkey':
        try:
            address = wallet.import_private_key(args.privkey, args.label)
            print(f"\n✓ Clave privada importada")
            print(f"Dirección: {address}")
            if args.label:
                print(f"Etiqueta: {args.label}")
        except Exception as e:
            print(f"\n✗ Error importando clave: {e}")
    
    elif args.command == 'backupwallet':
        try:
            wallet.backup_wallet(args.destination)
            print(f"\n✓ Backup creado en {args.destination}")
        except Exception as e:
            print(f"\n✗ Error creando backup: {e}")


if __name__ == '__main__':
    main()
