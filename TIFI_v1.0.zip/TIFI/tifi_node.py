#!/usr/bin/env python3
"""
TIFI Node - Aplicación principal
Integra blockchain, wallet, minería, staking y red P2P
"""

import sys
import os
import asyncio
import signal

# Añadir directorios al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'core'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'wallet'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'mining'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'network'))

from blockchain import Blockchain
from consensus import HybridConsensus
from wallet import Wallet
from miner import MiningManager
from staking import StakingManager
from node import NetworkNode


class TIFINode:
    """Nodo TIFI completo"""
    
    def __init__(self, data_dir: str = "~/.tifi", port: int = 8333):
        self.data_dir = os.path.expanduser(data_dir)
        self.port = port
        
        print("="*60)
        print("  TIFI - Time Fidelity Blockchain")
        print("  Inicializando nodo...")
        print("="*60)
        
        # Inicializar componentes
        print("\n[1/6] Inicializando blockchain...")
        self.blockchain = Blockchain(data_dir)
        print(f"  ✓ Altura: {self.blockchain.get_height()}")
        
        print("\n[2/6] Inicializando consenso híbrido PoW/PoS...")
        self.consensus = HybridConsensus(self.blockchain)
        print(f"  ✓ Próximo bloque: {self.blockchain.get_next_block_type().upper()}")
        
        print("\n[3/6] Inicializando wallet...")
        self.wallet = Wallet(self.blockchain, data_dir)
        
        if not self.wallet.key_manager.has_wallet():
            print("  ! No se encontró wallet, creando uno nuevo...")
            mnemonic = self.wallet.create_new_wallet()
            print("\n" + "="*60)
            print("  ⚠️  IMPORTANTE: GUARDA ESTAS 24 PALABRAS ⚠️")
            print("="*60)
            words = mnemonic.split()
            for i in range(0, 24, 4):
                print(f"  {i+1:2d}. {words[i]:12s} {i+2:2d}. {words[i+1]:12s} {i+3:2d}. {words[i+2]:12s} {i+4:2d}. {words[i+3]:12s}")
            print("="*60)
            print("  Estas palabras son necesarias para recuperar tu wallet.")
            print("  ¡GUÁRDALAS EN UN LUGAR SEGURO!")
            print("="*60 + "\n")
            
            # Generar primera dirección
            address = self.wallet.get_new_address("Principal")
            print(f"  ✓ Primera dirección: {address}")
        else:
            print(f"  ✓ Wallet cargado: {len(self.wallet.get_all_addresses())} direcciones")
        
        print(f"  ✓ Balance: {self.wallet.get_balance():.4f} CRED")
        
        print("\n[4/6] Inicializando minero CPU...")
        self.mining_manager = MiningManager(self.blockchain, self.wallet, self.consensus)
        print(f"  ✓ {self.mining_manager.solo_miner.threads} threads disponibles")
        
        print("\n[5/6] Inicializando sistema de staking...")
        self.staking_manager = StakingManager(self.blockchain, self.wallet, self.consensus)
        print(f"  ✓ Stake mínimo: {self.consensus.pos.MIN_STAKE} CRED")
        
        print("\n[6/6] Inicializando red P2P...")
        self.network_node = NetworkNode(self.blockchain, port)
        print(f"  ✓ Puerto: {port}")
        
        self.running = False
        
        print("\n" + "="*60)
        print("  ✓ Nodo TIFI inicializado correctamente")
        print("="*60 + "\n")
    
    async def start(self):
        """Inicia el nodo"""
        print("Iniciando nodo TIFI...\n")
        
        self.running = True
        
        # Iniciar red P2P
        await self.network_node.start()
        
        # Sincronizar blockchain
        print("\nSincronizando blockchain...")
        await self.network_node.sync_blockchain()
        
        print("\n" + "="*60)
        print("  🚀 NODO TIFI EN EJECUCIÓN")
        print("="*60)
        self._print_status()
        print("="*60 + "\n")
        
        # Iniciar minería automáticamente
        print("Iniciando minería automática...")
        self.start_mining()
        print("✓ Minería iniciada\n")
        
        # Mantener el nodo corriendo
        try:
            while self.running:
                await asyncio.sleep(60)
                self._print_status()
        except KeyboardInterrupt:
            print("\n\nInterrupción recibida...")
        finally:
            await self.stop()
    
    async def stop(self):
        """Detiene el nodo"""
        print("\nDeteniendo nodo TIFI...")
        
        self.running = False
        
        # Detener minería y staking
        self.mining_manager.stop_mining()
        self.staking_manager.stop_staking()
        
        # Detener red
        await self.network_node.stop()
        
        print("✓ Nodo detenido correctamente\n")
    
    def _print_status(self):
        """Imprime el estado actual del nodo"""
        stats = self.blockchain.get_network_stats()
        mining_stats = self.mining_manager.get_stats()
        staking_stats = self.staking_manager.get_stats()
        network_stats = self.network_node.get_stats()
        
        print(f"\n[Estado del Nodo - {self._get_timestamp()}]")
        print(f"  Blockchain:")
        print(f"    Altura: {stats['height']}")
        print(f"    Dificultad: {stats['difficulty']}")
        print(f"    Supply: {stats['total_supply']:.2f} / {stats['max_supply']:,.0f} CRED")
        print(f"    Mempool: {stats['mempool_size']} transacciones")
        
        print(f"  Red P2P:")
        print(f"    Peers: {network_stats['connected_peers']} conectados")
        print(f"    Mensajes: {network_stats['messages_received']} recibidos")
        
        print(f"  Wallet:")
        print(f"    Balance: {self.wallet.get_balance():.4f} CRED")
        print(f"    Direcciones: {len(self.wallet.get_all_addresses())}")
        
        print(f"  Minería:")
        if mining_stats['mining']:
            print(f"    Estado: ACTIVO ✓")
            print(f"    Hashrate: {mining_stats['hashrate']:.2f} H/s")
            print(f"    Bloques encontrados: {mining_stats['blocks_found']}")
        else:
            print(f"    Estado: INACTIVO")
        
        print(f"  Staking:")
        if staking_stats['staking']:
            print(f"    Estado: ACTIVO ✓")
            print(f"    Staked: {staking_stats['total_staked']:.2f} CRED")
            print(f"    Bloques validados: {staking_stats['blocks_validated']}")
            print(f"    Recompensas: {staking_stats['total_rewards']:.4f} CRED")
        else:
            print(f"    Estado: INACTIVO")
    
    def _get_timestamp(self):
        """Obtiene timestamp formateado"""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Comandos interactivos
    
    def start_mining(self):
        """Inicia minería"""
        self.mining_manager.start_solo_mining()
    
    def stop_mining(self):
        """Detiene minería"""
        self.mining_manager.stop_mining()
    
    def start_staking(self):
        """Inicia staking"""
        self.staking_manager.start_staking()
    
    def stop_staking(self):
        """Detiene staking"""
        self.staking_manager.stop_staking()
    
    def get_balance(self):
        """Obtiene balance"""
        return self.wallet.get_balance()
    
    def get_address(self):
        """Obtiene nueva dirección"""
        return self.wallet.get_new_address()
    
    def send(self, to_address: str, amount: float):
        """Envía CRED"""
        return self.wallet.send(to_address, amount)


async def main():
    """Función principal"""
    # Crear nodo
    node = TIFINode()
    
    # Configurar señales para cierre graceful
    def signal_handler(sig, frame):
        print("\n\nSeñal de interrupción recibida...")
        node.running = False
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Iniciar nodo
    await node.start()


if __name__ == "__main__":
    # Ejecutar nodo
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nNodo detenido por el usuario")
    except Exception as e:
        print(f"\n\nError fatal: {e}")
        import traceback
        traceback.print_exc()
